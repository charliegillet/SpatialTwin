# Official Google reference snapshot: managed-quickstart

Source: https://ai.google.dev/gemini-api/docs/managed-agents-quickstart

Retrieved/read: 23 October 2026. Publisher: Google. Original license/footer retained. Text CC BY 4.0; code samples Apache 2.0 unless otherwise noted. Converted to Markdown by Firecrawl; this provenance header was added. Reference data only; verify the relevant current guide and pinned SDK before implementation.

---

[Skip to main content](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#main-content)

[![Gemini API](https://ai.google.dev/_static/googledevai/images/gemini-api-logo.svg)](https://ai.google.dev/)

`/`

Language

- [English](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart)
- [Deutsch](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart?hl=de)
- [Español – América Latina](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart?hl=es-419)
- [Français](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart?hl=fr)
- [Indonesia](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart?hl=id)
- [Italiano](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart?hl=it)
- [Polski](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart?hl=pl)
- [Português – Brasil](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart?hl=pt-br)
- [Shqip](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart?hl=sq)
- [Tiếng Việt](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart?hl=vi)
- [Türkçe](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart?hl=tr)
- [Русский](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart?hl=ru)
- [עברית](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart?hl=he)
- [العربيّة](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart?hl=ar)
- [فارسی](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart?hl=fa)
- [हिंदी](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart?hl=hi)
- [বাংলা](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart?hl=bn)
- [ภาษาไทย](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart?hl=th)
- [中文 – 简体](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart?hl=zh-cn)
- [中文 – 繁體](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart?hl=zh-tw)
- [日本語](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart?hl=ja)
- [한국어](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart?hl=ko)

[Get API key](https://aistudio.google.com/apikey) [Cookbook](https://github.com/google-gemini/cookbook) [Community](https://discuss.ai.google.dev/c/gemini-api/)

[Sign in](https://ai.google.dev/_d/signin?continue=https%3A%2F%2Fai.google.dev%2Fgemini-api%2Fdocs%2Fmanaged-agents-quickstart&prompt=select_account)

- On this page
- [Run your first agent interaction](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#run_your_first_agent_interaction)
- [Continue the conversation (multi-turn)](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#continue-conversation)
  - [Automatic context compaction](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#automatic_context_compaction)
- [Stream the response](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#stream-response)
- [Download files from the environment](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#download-files)
- [Save a managed agent](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#save-managed-agent)
- [Invoke the managed agent](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#invoke-managed-agent)
- [What's next](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#whats-next)

Gemini 4 Argon is now available. [Try it out](https://aistudio.google.com/prompts/new_chat?model=gemini-4-argon).


- [Home](https://ai.google.dev/)
- [Gemini API](https://ai.google.dev/gemini-api)
- [Docs](https://ai.google.dev/gemini-api/docs)

Was this helpful?



 Send feedback



# Managed agents quickstart

- On this page
- [Run your first agent interaction](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#run_your_first_agent_interaction)
- [Continue the conversation (multi-turn)](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#continue-conversation)
  - [Automatic context compaction](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#automatic_context_compaction)
- [Stream the response](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#stream-response)
- [Download files from the environment](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#download-files)
- [Save a managed agent](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#save-managed-agent)
- [Invoke the managed agent](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#invoke-managed-agent)
- [What's next](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#whats-next)

This guide walks you through creating and using Managed Agents on the Gemini
API, using the [Antigravity agent](https://ai.google.dev/gemini-api/docs/antigravity-agent). You'll
make your first agent call, continue a multi-turn conversation, stream the
response, download files from the sandbox, and work with the Antigravity
managed agent.

## Run your first agent interaction

A single call to the [Interactions API](https://ai.google.dev/gemini-api/docs) provisions a Linux sandbox, runs the agent loop, and returns the result. You'll define three parameters:

- Pass in the `agent` as `"antigravity-preview-09-2026"`, which is the current version of our predefined and general purpose managed agent.
- Define `environment="remote"`, to provision a new, fresh sandbox environment.
- Create an input, defining what you want the agent to do.


[Python](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#python)[JavaScript](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#javascript)[Java](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#java)[Go](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#go)[REST](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#rest)More

```
from google import genai

client = genai.Client()

interaction = client.interactions.create(
    agent="antigravity-preview-09-2026",
    input="Write a Python script that generates the first 20 Fibonacci numbers and saves them to fibonacci.txt. Then read the file and print its contents.",
    environment="remote",
)

# Print the agent's final output
print(f"Interaction ID: {interaction.id}")
print(f"Environment ID: {interaction.environment_id}")
print(f"Output: {interaction.output_text}")
```

```
import { GoogleGenAI } from "@google/genai";

const client = new GoogleGenAI({});

const interaction = await client.interactions.create({
    agent: "antigravity-preview-09-2026",
    input: "Write a Python script that generates the first 20 Fibonacci numbers and saves them to fibonacci.txt. Then read the file and print its contents.",
    environment: "remote",
});

console.log(`Interaction ID: ${interaction.id}`);
console.log(`Environment ID: ${interaction.environment_id}`);

console.log(`Output: ${interaction.output_text}`);
```

```
import com.google.genai.Client;
import com.google.genai.gaos.models.interactions.AgentOption;
import com.google.genai.gaos.models.interactions.CreateAgentInteraction;
import com.google.genai.gaos.models.interactions.CreateAgentInteractionEnvironment;
import com.google.genai.gaos.models.interactions.Interaction;
import com.google.genai.gaos.models.interactions.InteractionsInput;
import com.google.genai.gaos.models.operations.CreateInteractionRequestBody;

Client client = new Client();

CreateAgentInteraction params = CreateAgentInteraction.builder()
    .agent(AgentOption.of("antigravity-preview-09-2026"))
    .input(InteractionsInput.of("Write a Python script that generates the first 20 Fibonacci numbers and saves them to fibonacci.txt. Then read the file and print its contents."))
    .environment(CreateAgentInteractionEnvironment.of("remote"))
    .build();

Interaction interaction = client.interactions.create(CreateInteractionRequestBody.of(params)).interaction().get();

// Print the agent's final output
System.out.println("Interaction ID: " + interaction.id().orElse(""));
System.out.println("Environment ID: " + interaction.environmentId().orElse(""));
System.out.println("Output: " + interaction.outputText().orElse(""));
```

```
package main

import (
    "context"
    "fmt"
    "log"

    "google.golang.org/genai"
    "google.golang.org/genai/interactions/models/interactions"
    "google.golang.org/genai/interactions/models/operations"
)

func main() {
    ctx := context.Background()
    client, err := genai.NewClient(ctx, nil)
    if err != nil {
        log.Fatal(err)
    }

    res, err := client.Interactions.Create(ctx, operations.CreateInteractionRequest{
        Body: operations.NewCreateInteractionRequestBody(interactions.CreateAgentInteraction{
            Agent:       interactions.AgentOption("antigravity-preview-09-2026"),
            Input:       interactions.NewInteractionsInput("Write a Python script that generates the first 20 Fibonacci numbers and saves them to fibonacci.txt. Then read the file and print its contents."),
            Environment: genai.Ptr(interactions.NewCreateAgentInteractionEnvironment("remote")),
        }),
    })
    if err != nil {
        log.Fatal(err)
    }

    interaction := res.Interaction
    // Print the agent's final output
    fmt.Printf("Interaction ID: %s\n", *interaction.ID)
    fmt.Printf("Environment ID: %s\n", *interaction.EnvironmentID)
    fmt.Printf("Output: %s\n", *interaction.OutputText)
}
```

```
curl -X POST "https://generativelanguage.googleapis.com/v1beta/interactions" \
-H "Content-Type: application/json" \
-H "x-goog-api-key: $GEMINI_API_KEY" \
-d '{
    "agent": "antigravity-preview-09-2026",
    "input": [{"type": "text", "text": "Write a Python script that generates the first 20 Fibonacci numbers and saves them to fibonacci.txt. Then read the file and print its contents."}],
    "environment": {"type": "remote"}
}'
```

The response returns an `Interaction` object. Store `interaction.id` and `interaction.environment_id` to continue the conversation in the same sandbox. Use `interaction.output_text` to access the agent's final response. `interaction.steps` lists each step the agent took (reasoning, tool calls, code execution).

## Continue the conversation (multi-turn)

The API tracks two independent state dimensions:

- **Conversation context:** chat history, reasoning trace, tool use, using `previous_interaction_id`.
- [**Environment state:**](https://ai.google.dev/gemini-api/docs/agent-environment) files, installed packages and sandbox state, using `environment`.

Pass both in their respective place to resume:

[Python](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#python)[JavaScript](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#javascript)[Java](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#java)[Go](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#go)[REST](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#rest)More

```
interaction_2 = client.interactions.create(
    agent="antigravity-preview-09-2026",
    previous_interaction_id=interaction.id,
    environment=interaction.environment_id,
    input="Now plot the Fibonacci sequence as a line chart and save it as chart.png.",
)

print(interaction_2.output_text)
```

```
const interaction2 = await client.interactions.create({
    agent: "antigravity-preview-09-2026",
    previous_interaction_id: interaction.id,
    environment: interaction.environment_id,
    input: "Now plot the Fibonacci sequence as a line chart and save it as chart.png.",
}, { timeout: 300_000 });

console.log(interaction2.output_text);
```

```
import com.google.genai.Client;
import com.google.genai.gaos.models.interactions.AgentOption;
import com.google.genai.gaos.models.interactions.CreateAgentInteraction;
import com.google.genai.gaos.models.interactions.CreateAgentInteractionEnvironment;
import com.google.genai.gaos.models.interactions.Interaction;
import com.google.genai.gaos.models.interactions.InteractionsInput;
import com.google.genai.gaos.models.operations.CreateInteractionRequestBody;

Client client = new Client();
String interactionId = "INTERACTION_ID";
String environmentId = "ENVIRONMENT_ID";

CreateAgentInteraction params = CreateAgentInteraction.builder()
    .agent(AgentOption.of("antigravity-preview-09-2026"))
    .previousInteractionId(interactionId)
    .environment(CreateAgentInteractionEnvironment.of(environmentId))
    .input(InteractionsInput.of("Now plot the Fibonacci sequence as a line chart and save it as chart.png."))
    .build();

Interaction interaction2 = client.interactions.create(CreateInteractionRequestBody.of(params)).interaction().get();
System.out.println(interaction2.outputText().orElse(""));
```

```
package main

import (
    "context"
    "fmt"
    "log"

    "google.golang.org/genai"
    "google.golang.org/genai/interactions/models/interactions"
    "google.golang.org/genai/interactions/models/operations"
)

func main() {
    ctx := context.Background()
    client, err := genai.NewClient(ctx, nil)
    if err != nil {
        log.Fatal(err)
    }

    interactionID := "INTERACTION_ID"
    environmentID := "ENVIRONMENT_ID"

    res, err := client.Interactions.Create(ctx, operations.CreateInteractionRequest{
        Body: operations.NewCreateInteractionRequestBody(interactions.CreateAgentInteraction{
            Agent:                 interactions.AgentOption("antigravity-preview-09-2026"),
            PreviousInteractionID: genai.Ptr(interactionID),
            Environment:           genai.Ptr(interactions.NewCreateAgentInteractionEnvironment(environmentID)),
            Input:                 interactions.NewInteractionsInput("Now plot the Fibonacci sequence as a line chart and save it as chart.png."),
        }),
    })
    if err != nil {
        log.Fatal(err)
    }
    if res.Interaction.OutputText != nil {
        fmt.Println(*res.Interaction.OutputText)
    }
}
```

```
curl -X POST "https://generativelanguage.googleapis.com/v1beta/interactions" \
-H "Content-Type: application/json" \
-H "x-goog-api-key: $GEMINI_API_KEY" \
-d '{
    "agent": "antigravity-preview-09-2026",
    "previous_interaction_id": "interaction_id_from_step_1",
    "environment": "environment_id_from_step_1",
    "input": [{"type": "text", "text": "Now plot the Fibonacci sequence as a line chart and save it as chart.png."}]
}'
```

Files from turn 1 (`fibonacci.txt`) persist in turn 2. The agent also retains conversation context.

You can mix and match these independently:

- **Clear conversation, keep files:** Omit `previous_interaction_id`, only pass the environment ID using `environment` for a fresh conversation in the same workspace.
- **Keep conversation, new workspace:** Pass `previous_interaction_id`, set `environment="remote"` for a fresh sandbox.

### Automatic context compaction

In long-running, multi-turn conversations, the raw history of reasoning steps, tool calls, and large file contents can quickly grow and consume significant context space. To prevent token limit errors and maintain the agent's focus (preventing "context rot"), the Managed Agents API features a native context compaction step at around 135k tokens. This happens automatically.

## Stream the response

For long-running tasks, you can stream the response to see the agent work in real time:

[Python](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#python)[JavaScript](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#javascript)[Java](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#java)[Go](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#go)[REST](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#rest)More

```
from google import genai

client = genai.Client()

stream = client.interactions.create(
    agent="antigravity-preview-09-2026",
    input="Read Hacker News, summarize the top 5 stories, and save the results as a PDF.",
    environment="remote",
    stream=True,
)

for event in stream:
    print(event)
    if event.event_type == "step.stop" and event.usage:
        print(event.usage)
```

```
import { GoogleGenAI } from "@google/genai";

const client = new GoogleGenAI({});

const stream = await client.interactions.create({
    agent: "antigravity-preview-09-2026",
    input: "Read Hacker News, summarize the top 5 stories, and save the results as a PDF.",
    environment: "remote",
    stream: true,
});

for await (const event of stream) {
    console.log(event);
    if (event.event_type === "step.stop" && event.usage) {
        console.log(event.usage);
    }
}
```

```
import com.google.genai.Client;
import com.google.genai.gaos.models.interactions.AgentOption;
import com.google.genai.gaos.models.interactions.CreateAgentInteraction;
import com.google.genai.gaos.models.interactions.CreateAgentInteractionEnvironment;
import com.google.genai.gaos.models.interactions.InteractionSSEStreamEvent;
import com.google.genai.gaos.models.interactions.InteractionsInput;
import com.google.genai.gaos.models.interactions.StepStop;
import com.google.genai.gaos.models.operations.CreateInteractionRequestBody;
import com.google.genai.gaos.utils.EventStream;

Client client = new Client();

CreateAgentInteraction params = CreateAgentInteraction.builder()
    .agent(AgentOption.of("antigravity-preview-09-2026"))
    .input(InteractionsInput.of("Read Hacker News, summarize the top 5 stories, and save the results as a PDF."))
    .environment(CreateAgentInteractionEnvironment.of("remote"))
    .stream(true)
    .build();

try (EventStream<InteractionSSEStreamEvent> stream =
    client.interactions.create(CreateInteractionRequestBody.of(params)).events()) {
  for (InteractionSSEStreamEvent event : stream) {
    System.out.println(event);
    if (event.data().isPresent() && event.data().get() instanceof StepStop stepStop) {
      stepStop.usage().ifPresent(System.out::println);
    }
  }
}
```

```
package main

import (
    "context"
    "fmt"
    "log"

    "google.golang.org/genai"
    "google.golang.org/genai/interactions/models/interactions"
    "google.golang.org/genai/interactions/models/operations"
)

func main() {
    ctx := context.Background()
    client, err := genai.NewClient(ctx, nil)
    if err != nil {
        log.Fatal(err)
    }

    res, err := client.Interactions.Create(ctx, operations.CreateInteractionRequest{
        Body: operations.NewCreateInteractionRequestBody(interactions.CreateAgentInteraction{
            Agent:       interactions.AgentOption("antigravity-preview-09-2026"),
            Input:       interactions.NewInteractionsInput("Read Hacker News, summarize the top 5 stories, and save the results as a PDF."),
            Environment: genai.Ptr(interactions.NewCreateAgentInteractionEnvironment("remote")),
            Stream:      genai.Ptr(true),
        }),
    })
    if err != nil {
        log.Fatal(err)
    }

    stream := res.InteractionSSEStreamEvent
    defer stream.Close()

    for stream.Next() {
        event := stream.Value()
        fmt.Printf("%+v\n", event)
        if stepStop := event.GetDataStepStop(); stepStop != nil && stepStop.Usage != nil {
            fmt.Printf("%+v\n", stepStop.Usage)
        }
    }
    if err := stream.Err(); err != nil {
        log.Fatal(err)
    }
}
```

```
curl -N -s -X POST "https://generativelanguage.googleapis.com/v1beta/interactions" \
-H "Content-Type: application/json" \
-H "x-goog-api-key: $GEMINI_API_KEY" \
-d '{
    "agent": "antigravity-preview-09-2026",
    "input": "Read Hacker News, summarize the top 5 stories, and save the results as a PDF.",
    "environment": "remote",
    "stream": true
}'
```

Streaming returns step deltas with incremental updates. When a step completes,
the `step.stop` event includes accumulated usage stats. Learn more in the
[Streaming guide](https://ai.google.dev/gemini-api/docs/streaming).

## Download files from the environment

When the agent creates files inside the sandbox. Download them using the Files API with a direct HTTP request (no SDK method yet):

[Python](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#python)[JavaScript](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#javascript)[Java](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#java)[Go](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#go)[REST](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#rest)More

```
import os
import requests
import tarfile

env_id = interaction.environment_id
api_key = os.environ["GEMINI_API_KEY"]

response = requests.get(
    f"https://generativelanguage.googleapis.com/v1beta/files/environment-{env_id}:download",
    params={"alt": "media"},
    headers={"x-goog-api-key": api_key},
    allow_redirects=True,
)

with open("snapshot.tar", "wb") as f:
    f.write(response.content)

with tarfile.open("snapshot.tar") as tar:
    tar.extractall(path="extracted_snapshot")
```

```
import fs from "fs";
import { execSync } from "child_process";

const envId = interaction.environment_id;
const apiKey = process.env.GEMINI_API_KEY || "";

const url = `https://generativelanguage.googleapis.com/v1beta/files/environment-${envId}:download?alt=media`;
const response = await fetch(url, {
    headers: {
        "x-goog-api-key": apiKey,
    },
});

if (!response.ok) {
    throw new Error(`Failed to download file: ${response.statusText}`);
}

const buffer = Buffer.from(await response.arrayBuffer());
fs.writeFileSync("snapshot.tar", buffer);

if (!fs.existsSync("extracted_snapshot")) {
    fs.mkdirSync("extracted_snapshot");
}
execSync("tar -xf snapshot.tar -C extracted_snapshot");

console.log(fs.readdirSync("extracted_snapshot"));
```

```
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Paths;

String envId = "ENVIRONMENT_ID";
String apiKey = System.getenv("GEMINI_API_KEY");

HttpClient httpClient = HttpClient.newBuilder()
    .followRedirects(HttpClient.Redirect.NORMAL)
    .build();

HttpRequest request = HttpRequest.newBuilder()
    .uri(URI.create("https://generativelanguage.googleapis.com/v1beta/files/environment-" + envId + ":download?alt=media"))
    .header("x-goog-api-key", apiKey)
    .GET()
    .build();

HttpResponse<byte[]> response = httpClient.send(request, HttpResponse.BodyHandlers.ofByteArray());
Files.write(Paths.get("snapshot.tar"), response.body());
System.out.println("Saved snapshot to snapshot.tar");
```

```
package main

import (
    "context"
    "fmt"
    "io"
    "log"
    "net/http"
    "os"
)

func main() {
    ctx := context.Background()
    envID := "ENVIRONMENT_ID"
    apiKey := os.Getenv("GEMINI_API_KEY")

    url := fmt.Sprintf("https://generativelanguage.googleapis.com/v1beta/files/environment-%s:download?alt=media", envID)
    req, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
    if err != nil {
        log.Fatal(err)
    }
    req.Header.Set("x-goog-api-key", apiKey)

    resp, err := http.DefaultClient.Do(req)
    if err != nil {
        log.Fatal(err)
    }
    defer resp.Body.Close()

    data, err := io.ReadAll(resp.Body)
    if err != nil {
        log.Fatal(err)
    }
    if err := os.WriteFile("snapshot.tar", data, 0644); err != nil {
        log.Fatal(err)
    }
    fmt.Println("Saved snapshot to snapshot.tar")
}
```

```
ENV_ID="your_environment_id_here"

curl -L -X GET "https://generativelanguage.googleapis.com/v1beta/files/environment-$ENV_ID:download?alt=media" \
-H "x-goog-api-key: $GEMINI_API_KEY" \
-o snapshot.tar

mkdir -p extracted_snapshot
tar -xf snapshot.tar -C extracted_snapshot
```

## Save a managed agent

In the previous steps, we used the default Antigravity agent and customized it inline. Once you have iterated on your configuration (instructions, skills, model selection, and environment), you can save it as a reusable managed agent. This allows you to invoke it by ID without repeating the configuration.

When you save an agent, notice the architectural symmetry with inline interactions: you specify `base_agent: "antigravity-preview-09-2026"` and can pass an `agent_config` with your chosen `model` just as you would on `interactions.create`. You also define a `base_environment` (either from sources or by forking an existing environment). The agent will use this environment and model configuration for every new interaction.

**From sources:** Define sources inline, or from other sources such as GitHub or Cloud Storage.

[Python](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#python)[JavaScript](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#javascript)[Java](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#java)[Go](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#go)[REST](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#rest)More

```
agent = client.agents.create(
    id="fibonacci-analyst",
    base_agent="antigravity-preview-09-2026",
    agent_config={
        "type": "antigravity",
        "model": "gemini-3.8-flash",
    },
    system_instruction="You are a math analysis agent. Generate sequences, visualize them, and export results as PDF reports.",
    base_environment={
        "type": "remote",
        "sources": [\
            {\
                "type": "inline",\
                "target": ".agents/AGENTS.md",\
                "content": "Always include a chart and a summary table in your reports.",\
            },\
            {\
                "type": "repository",\
                "source": "https://github.com/your-org/skills",\
                "target": ".agents/skills"\
            }\
        ],
    },
)

print(f"Saved agent: {agent.id}")
```

```
const agent = await client.agents.create({
    id: "fibonacci-analyst",
    base_agent: "antigravity-preview-09-2026",
    agent_config: {
        type: "antigravity",
        model: "gemini-3.8-flash",
    },
    system_instruction: "You are a math analysis agent. Generate sequences, visualize them, and export results as PDF reports.",
    base_environment: {
        type: "remote",
        sources: [\
            {\
                type: "inline",\
                target: ".agents/AGENTS.md",\
                content: "Always include a chart and a summary table in your reports.",\
            },\
            {\
                type: "repository",\
                source: "https://github.com/your-org/skills",\
                target: ".agents/skills"\
            }\
        ],
    },
});

console.log(`Saved agent: ${agent.id}`);
```

```
import com.google.genai.Client;
import com.google.genai.gaos.models.agents.Agent;
import com.google.genai.gaos.models.agents.AgentConfig;
import com.google.genai.gaos.models.agents.BaseEnvironment;
import com.google.genai.gaos.models.interactions.AntigravityAgentConfig;
import com.google.genai.gaos.models.interactions.Environment;
import com.google.genai.gaos.models.interactions.Source;
import com.google.genai.gaos.models.interactions.SourceType;
import java.util.List;

Client client = new Client();

Environment env = Environment.builder()
    .sources(List.of(
        Source.builder()
            .type(SourceType.INLINE)
            .target(".agents/AGENTS.md")
            .content("Always include a chart and a summary table in your reports.")
            .build(),
        Source.builder()
            .type(SourceType.REPOSITORY)
            .source("https://github.com/your-org/skills")
            .target(".agents/skills")
            .build()
    ))
    .build();

Agent agentParams = Agent.builder()
    .id("fibonacci-analyst")
    .baseAgent("antigravity-preview-09-2026")
    .agentConfig(AgentConfig.of(
        AntigravityAgentConfig.builder()
            .model("gemini-3.8-flash")
            .build()
    ))
    .systemInstruction("You are a math analysis agent. Generate sequences, visualize them, and export results as PDF reports.")
    .baseEnvironment(BaseEnvironment.of(env))
    .build();

Agent agent = client.agents.create(agentParams).agent().get();
System.out.println("Saved agent: " + agent.id().orElse(""));
```

```
package main

import (
    "context"
    "fmt"
    "log"

    "google.golang.org/genai"
    "google.golang.org/genai/interactions/models/agents"
    "google.golang.org/genai/interactions/models/interactions"
    "google.golang.org/genai/interactions/models/operations"
)

func main() {
    ctx := context.Background()
    client, err := genai.NewClient(ctx, nil)
    if err != nil {
        log.Fatal(err)
    }

    env := interactions.Environment{
        Sources: []interactions.Source{
            {
                Type:    interactions.SourceTypeInline.ToPointer(),
                Target:  genai.Ptr(".agents/AGENTS.md"),
                Content: genai.Ptr("Always include a chart and a summary table in your reports."),
            },
            {
                Type:   interactions.SourceTypeRepository.ToPointer(),
                Source: genai.Ptr("https://github.com/your-org/skills"),
                Target: genai.Ptr(".agents/skills"),
            },
        },
    }

    res, err := client.Agents.Create(ctx, operations.CreateAgentRequest{
        Body: agents.Agent{
            ID:        genai.Ptr("fibonacci-analyst"),
            BaseAgent: genai.Ptr("antigravity-preview-09-2026"),
            AgentConfig: genai.Ptr(agents.NewAgentConfig(interactions.AntigravityAgentConfig{
                Model: genai.Ptr("gemini-3.8-flash"),
            })),
            SystemInstruction: genai.Ptr("You are a math analysis agent. Generate sequences, visualize them, and export results as PDF reports."),
            BaseEnvironment:   genai.Ptr(agents.NewBaseEnvironment(env)),
        },
    })
    if err != nil {
        log.Fatal(err)
    }

    fmt.Printf("Saved agent: %s\n", *res.Agent.ID)
}
```

```
curl -X POST "https://generativelanguage.googleapis.com/v1beta/agents" \
-H "Content-Type: application/json" \
-H "x-goog-api-key: $GEMINI_API_KEY" \
-d '{
    "id": "fibonacci-analyst",
    "base_agent": "antigravity-preview-09-2026",
    "agent_config": {
        "type": "antigravity",
        "model": "gemini-3.8-flash"
    },
    "system_instruction": "You are a math analysis agent. Generate sequences, visualize them, and export results as PDF reports.",
    "base_environment": {
        "type": "remote",
        "sources": [\
            {\
                "type": "inline",\
                "target": ".agents/AGENTS.md",\
                "content": "Always include a chart and a summary table in your reports."\
            },\
            {\
                "type": "repository",\
                "source": "https://github.com/your-org/skills",\
                "target": ".agents/skills"\
            }\
        ]
    }
}'
```

## Invoke the managed agent

Once you've saved a managed agent, you can invoke it by ID. Each invocation forks the base environment, so every run starts clean:

[Python](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#python)[JavaScript](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#javascript)[Java](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#java)[Go](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#go)[REST](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart#rest)More

```
result = client.interactions.create(
    agent="fibonacci-analyst",
    input="Generate the first 50 prime numbers, plot their distribution, and save a PDF report.",
    environment="remote",
)

print(result.output_text)
```

```
const result = await client.interactions.create({
    agent: "fibonacci-analyst",
    input: "Generate the first 50 prime numbers, plot their distribution, and save a PDF report.",
    environment: "remote",
}, {
    timeout: 300_000,
});

console.log(result.output_text);
```

```
import com.google.genai.Client;
import com.google.genai.gaos.models.interactions.AgentOption;
import com.google.genai.gaos.models.interactions.CreateAgentInteraction;
import com.google.genai.gaos.models.interactions.CreateAgentInteractionEnvironment;
import com.google.genai.gaos.models.interactions.Interaction;
import com.google.genai.gaos.models.interactions.InteractionsInput;
import com.google.genai.gaos.models.operations.CreateInteractionRequestBody;

Client client = new Client();

CreateAgentInteraction params = CreateAgentInteraction.builder()
    .agent(AgentOption.of("fibonacci-analyst"))
    .input(InteractionsInput.of("Generate the first 50 prime numbers, plot their distribution, and save a PDF report."))
    .environment(CreateAgentInteractionEnvironment.of("remote"))
    .build();

Interaction result = client.interactions.create(CreateInteractionRequestBody.of(params)).interaction().get();
System.out.println(result.outputText().orElse(""));
```

```
package main

import (
    "context"
    "fmt"
    "log"

    "google.golang.org/genai"
    "google.golang.org/genai/interactions/models/interactions"
    "google.golang.org/genai/interactions/models/operations"
)

func main() {
    ctx := context.Background()
    client, err := genai.NewClient(ctx, nil)
    if err != nil {
        log.Fatal(err)
    }

    res, err := client.Interactions.Create(ctx, operations.CreateInteractionRequest{
        Body: operations.NewCreateInteractionRequestBody(interactions.CreateAgentInteraction{
            Agent:       interactions.AgentOption("fibonacci-analyst"),
            Input:       interactions.NewInteractionsInput("Generate the first 50 prime numbers, plot their distribution, and save a PDF report."),
            Environment: genai.Ptr(interactions.NewCreateAgentInteractionEnvironment("remote")),
        }),
    })
    if err != nil {
        log.Fatal(err)
    }
    if res.Interaction.OutputText != nil {
        fmt.Println(*res.Interaction.OutputText)
    }
}
```

```
curl -X POST "https://generativelanguage.googleapis.com/v1beta/interactions" \
-H "Content-Type: application/json" \
-H "x-goog-api-key: $GEMINI_API_KEY" \
-d '{
    "agent": "fibonacci-analyst",
    "environment": "remote",
    "input": "Generate the first 50 prime numbers, plot their distribution, and save a PDF report."
}'
```

## What's next

- [Antigravity Agent](https://ai.google.dev/gemini-api/docs/antigravity-agent): capabilities, supported tools, multimodal input, pricing, and limitations.
- [Building Managed Agents](https://ai.google.dev/gemini-api/docs/custom-agents): extend Antigravity with your own instructions, skills, and data.
- [Environments](https://ai.google.dev/gemini-api/docs/agent-environment): sources, networking, lifecycle, resource limits.
- [Interactions API](https://ai.google.dev/gemini-api/docs/interactions-overview): the underlying API for models and agents.

Was this helpful?



 Send feedback



Except as otherwise noted, the content of this page is licensed under the [Creative Commons Attribution 4.0 License](https://creativecommons.org/licenses/by/4.0/), and code samples are licensed under the [Apache 2.0 License](https://www.apache.org/licenses/LICENSE-2.0). For details, see the [Google Developers Site Policies](https://developers.google.com/site-policies). Java is a registered trademark of Oracle and/or its affiliates.

Last updated 2026-10-01 UTC.


Need to tell us more?






\[\[\["Easy to understand","easyToUnderstand","thumb-up"\],\["Solved my problem","solvedMyProblem","thumb-up"\],\["Other","otherUp","thumb-up"\]\],\[\["Missing the information I need","missingTheInformationINeed","thumb-down"\],\["Too complicated / too many steps","tooComplicatedTooManySteps","thumb-down"\],\["Out of date","outOfDate","thumb-down"\],\["Samples / code issue","samplesCodeIssue","thumb-down"\],\["Other","otherDown","thumb-down"\]\],\["Last updated 2026-10-01 UTC."\],\[\],\[\]\]