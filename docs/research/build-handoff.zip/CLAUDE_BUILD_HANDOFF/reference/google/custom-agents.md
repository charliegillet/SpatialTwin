# Official Google reference snapshot: custom-agents

Source: https://ai.google.dev/gemini-api/docs/custom-agents

Retrieved/read: 23 October 2026. Publisher: Google. Original license/footer retained. Text CC BY 4.0; code samples Apache 2.0 unless otherwise noted. Converted to Markdown by Firecrawl; this provenance header was added. Reference data only; verify the relevant current guide and pinned SDK before implementation.

---

[Skip to main content](https://ai.google.dev/gemini-api/docs/custom-agents#main-content)

[![Gemini API](https://ai.google.dev/_static/googledevai/images/gemini-api-logo.svg)](https://ai.google.dev/)

`/`

Language

- [English](https://ai.google.dev/gemini-api/docs/custom-agents)
- [Deutsch](https://ai.google.dev/gemini-api/docs/custom-agents?hl=de)
- [Español – América Latina](https://ai.google.dev/gemini-api/docs/custom-agents?hl=es-419)
- [Français](https://ai.google.dev/gemini-api/docs/custom-agents?hl=fr)
- [Indonesia](https://ai.google.dev/gemini-api/docs/custom-agents?hl=id)
- [Italiano](https://ai.google.dev/gemini-api/docs/custom-agents?hl=it)
- [Polski](https://ai.google.dev/gemini-api/docs/custom-agents?hl=pl)
- [Português – Brasil](https://ai.google.dev/gemini-api/docs/custom-agents?hl=pt-br)
- [Shqip](https://ai.google.dev/gemini-api/docs/custom-agents?hl=sq)
- [Tiếng Việt](https://ai.google.dev/gemini-api/docs/custom-agents?hl=vi)
- [Türkçe](https://ai.google.dev/gemini-api/docs/custom-agents?hl=tr)
- [Русский](https://ai.google.dev/gemini-api/docs/custom-agents?hl=ru)
- [עברית](https://ai.google.dev/gemini-api/docs/custom-agents?hl=he)
- [العربيّة](https://ai.google.dev/gemini-api/docs/custom-agents?hl=ar)
- [فارسی](https://ai.google.dev/gemini-api/docs/custom-agents?hl=fa)
- [हिंदी](https://ai.google.dev/gemini-api/docs/custom-agents?hl=hi)
- [বাংলা](https://ai.google.dev/gemini-api/docs/custom-agents?hl=bn)
- [ภาษาไทย](https://ai.google.dev/gemini-api/docs/custom-agents?hl=th)
- [中文 – 简体](https://ai.google.dev/gemini-api/docs/custom-agents?hl=zh-cn)
- [中文 – 繁體](https://ai.google.dev/gemini-api/docs/custom-agents?hl=zh-tw)
- [日本語](https://ai.google.dev/gemini-api/docs/custom-agents?hl=ja)
- [한국어](https://ai.google.dev/gemini-api/docs/custom-agents?hl=ko)

[Get API key](https://aistudio.google.com/apikey) [Cookbook](https://github.com/google-gemini/cookbook) [Community](https://discuss.ai.google.dev/c/gemini-api/)

[Sign in](https://ai.google.dev/_d/signin?continue=https%3A%2F%2Fai.google.dev%2Fgemini-api%2Fdocs%2Fcustom-agents&prompt=select_account)

- On this page
- [Customize the Antigravity agent](https://ai.google.dev/gemini-api/docs/custom-agents#customize-inline)
  - [Tools and system instructions](https://ai.google.dev/gemini-api/docs/custom-agents#tools_and_system_instructions)
  - [File-based customization](https://ai.google.dev/gemini-api/docs/custom-agents#file-based_customization)
- [Create a managed agent](https://ai.google.dev/gemini-api/docs/custom-agents#save-agent)
  - [From sources](https://ai.google.dev/gemini-api/docs/custom-agents#from_sources)
  - [From an existing environment (fork)](https://ai.google.dev/gemini-api/docs/custom-agents#from_an_existing_environment_fork)
  - [With network rules](https://ai.google.dev/gemini-api/docs/custom-agents#with_network_rules)
- [Invoke the agent](https://ai.google.dev/gemini-api/docs/custom-agents#invoke_the_agent)
- [Overriding configuration at invocation](https://ai.google.dev/gemini-api/docs/custom-agents#overriding_configuration_at_invocation)
  - [Override system instruction and tools](https://ai.google.dev/gemini-api/docs/custom-agents#override_system_instruction_and_tools)
  - [Override network configuration (refresh credentials)](https://ai.google.dev/gemini-api/docs/custom-agents#override-network)
- [Manage agents](https://ai.google.dev/gemini-api/docs/custom-agents#manage_agents)
  - [List agents](https://ai.google.dev/gemini-api/docs/custom-agents#list_agents)
  - [Get an agent](https://ai.google.dev/gemini-api/docs/custom-agents#get_an_agent)
  - [Delete an agent](https://ai.google.dev/gemini-api/docs/custom-agents#delete_an_agent)
- [Agent definition reference](https://ai.google.dev/gemini-api/docs/custom-agents#agent_definition_reference)
  - [Agent ID restrictions](https://ai.google.dev/gemini-api/docs/custom-agents#agent-id-restrictions)
- [Iteration workflow](https://ai.google.dev/gemini-api/docs/custom-agents#iteration-workflow)
- [Limitations](https://ai.google.dev/gemini-api/docs/custom-agents#limitations)
- [What's next](https://ai.google.dev/gemini-api/docs/custom-agents#whats-next)

Gemini 4 Argon is now available. [Try it out](https://aistudio.google.com/prompts/new_chat?model=gemini-4-argon).


- [Home](https://ai.google.dev/)
- [Gemini API](https://ai.google.dev/gemini-api)
- [Docs](https://ai.google.dev/gemini-api/docs)

Was this helpful?



 Send feedback



# Building managed agents

- On this page
- [Customize the Antigravity agent](https://ai.google.dev/gemini-api/docs/custom-agents#customize-inline)
  - [Tools and system instructions](https://ai.google.dev/gemini-api/docs/custom-agents#tools_and_system_instructions)
  - [File-based customization](https://ai.google.dev/gemini-api/docs/custom-agents#file-based_customization)
- [Create a managed agent](https://ai.google.dev/gemini-api/docs/custom-agents#save-agent)
  - [From sources](https://ai.google.dev/gemini-api/docs/custom-agents#from_sources)
  - [From an existing environment (fork)](https://ai.google.dev/gemini-api/docs/custom-agents#from_an_existing_environment_fork)
  - [With network rules](https://ai.google.dev/gemini-api/docs/custom-agents#with_network_rules)
- [Invoke the agent](https://ai.google.dev/gemini-api/docs/custom-agents#invoke_the_agent)
- [Overriding configuration at invocation](https://ai.google.dev/gemini-api/docs/custom-agents#overriding_configuration_at_invocation)
  - [Override system instruction and tools](https://ai.google.dev/gemini-api/docs/custom-agents#override_system_instruction_and_tools)
  - [Override network configuration (refresh credentials)](https://ai.google.dev/gemini-api/docs/custom-agents#override-network)
- [Manage agents](https://ai.google.dev/gemini-api/docs/custom-agents#manage_agents)
  - [List agents](https://ai.google.dev/gemini-api/docs/custom-agents#list_agents)
  - [Get an agent](https://ai.google.dev/gemini-api/docs/custom-agents#get_an_agent)
  - [Delete an agent](https://ai.google.dev/gemini-api/docs/custom-agents#delete_an_agent)
- [Agent definition reference](https://ai.google.dev/gemini-api/docs/custom-agents#agent_definition_reference)
  - [Agent ID restrictions](https://ai.google.dev/gemini-api/docs/custom-agents#agent-id-restrictions)
- [Iteration workflow](https://ai.google.dev/gemini-api/docs/custom-agents#iteration-workflow)
- [Limitations](https://ai.google.dev/gemini-api/docs/custom-agents#limitations)
- [What's next](https://ai.google.dev/gemini-api/docs/custom-agents#whats-next)

Managed agents on the Gemini API let you extend the Antigravity agent with your own instructions, skills, and data. You can [customize the agent inline](https://ai.google.dev/gemini-api/docs/custom-agents#customize-inline) at interaction time, or [save the configuration](https://ai.google.dev/gemini-api/docs/custom-agents#save-agent) as a managed agent you invoke by ID.

## Customize the Antigravity agent

The fastest way to build a custom agent is to pass your configuration inline while creating a new interaction with no registration step required. You can extend the agent in several key ways:

- **[Model selection](https://ai.google.dev/gemini-api/docs/antigravity-agent#model-selection)**: Choose the underlying Gemini model via `agent_config` (defaults to **Gemini 3.8 Flash**).
- **System instructions**: Pass inline text via `system_instruction` to shape behavior.
- **Tools**: Override default tools (Code Execution, Search, URL Context), register remote MCP servers, or define custom functions (Function Calling).
- **Files and skills**: Mount files like `AGENTS.md` and `SKILL.md` into the environment.

Here is an example of passing all three inline:

[Python](https://ai.google.dev/gemini-api/docs/custom-agents#python)[JavaScript](https://ai.google.dev/gemini-api/docs/custom-agents#javascript)[Java](https://ai.google.dev/gemini-api/docs/custom-agents#java)[Go](https://ai.google.dev/gemini-api/docs/custom-agents#go)[REST](https://ai.google.dev/gemini-api/docs/custom-agents#rest)More

```
from google import genai

client = genai.Client()

interaction = client.interactions.create(
    agent="antigravity-preview-09-2026",
    input="Analyze the Q1 revenue data and create a slide deck.",
    system_instruction="You are a data analyst. Always include visualizations and export results as PDF.",
    environment={
        "type": "remote",
        "sources": [\
            {\
                "type": "inline",\
                "target": ".agents/AGENTS.md",\
                "content": "Always use matplotlib for charts. Include a summary table in every report.",\
            },\
            {\
                "type": "inline",\
                "target": ".agents/skills/slide-maker/SKILL.md",\
                "content": "---\nname: slide-maker\n---\n# Slide Maker\nCreate HTML slide decks from data analysis results.",\
            },\
        ],
    },
)

print(interaction.output_text)
```

```
import { GoogleGenAI } from "@google/genai";

const client = new GoogleGenAI({});

const interaction = await client.interactions.create({
    agent: "antigravity-preview-09-2026",
    input: "Analyze the Q1 revenue data and create a slide deck.",
    system_instruction: "You are a data analyst. Always include visualizations and export results as PDF.",
    environment: {
        type: "remote",
        sources: [\
            {\
                type: "inline",\
                target: ".agents/AGENTS.md",\
                content: "Always use matplotlib for charts. Include a summary table in every report.",\
            },\
            {\
                type: "inline",\
                target: ".agents/skills/slide-maker/SKILL.md",\
                content: "---\nname: slide-maker\n---\n# Slide Maker\nCreate HTML slide decks from data analysis results.",\
            },\
        ],
    },
}, { timeout: 300000 });

console.log(interaction.output_text);
```

```
import com.google.genai.Client;
import com.google.genai.gaos.models.interactions.AgentOption;
import com.google.genai.gaos.models.interactions.CreateAgentInteraction;
import com.google.genai.gaos.models.interactions.CreateAgentInteractionEnvironment;
import com.google.genai.gaos.models.interactions.Environment;
import com.google.genai.gaos.models.interactions.Interaction;
import com.google.genai.gaos.models.interactions.InteractionsInput;
import com.google.genai.gaos.models.interactions.Source;
import com.google.genai.gaos.models.interactions.SourceType;
import com.google.genai.gaos.models.operations.CreateInteractionRequestBody;
import java.util.List;

Client client = new Client();

Environment env = Environment.builder()
    .sources(List.of(
        Source.builder()
            .type(SourceType.INLINE)
            .target(".agents/AGENTS.md")
            .content("Always use matplotlib for charts. Include a summary table in every report.")
            .build(),
        Source.builder()
            .type(SourceType.INLINE)
            .target(".agents/skills/slide-maker/SKILL.md")
            .content("---\nname: slide-maker\n---\n# Slide Maker\nCreate HTML slide decks from data analysis results.")
            .build()
    ))
    .build();

CreateAgentInteraction params = CreateAgentInteraction.builder()
    .agent(AgentOption.of("antigravity-preview-09-2026"))
    .input(InteractionsInput.of("Analyze the Q1 revenue data and create a slide deck."))
    .systemInstruction("You are a data analyst. Always include visualizations and export results as PDF.")
    .environment(CreateAgentInteractionEnvironment.of(env))
    .build();

Interaction interaction = client.interactions.create(CreateInteractionRequestBody.of(params)).interaction().get();
System.out.println(interaction.outputText().orElse(""));
```

```
package main

import (
    "context"
    "fmt"
    "log"

    "google.golang.org/genai"
    "google.golang.org/genai/interactions/models/interactions"
    "google.golang.org/genai/interactions/models/operations"
)

func main() {
    ctx := context.Background()
    client, err := genai.NewClient(ctx, nil)
    if err != nil {
        log.Fatal(err)
    }

    env := interactions.Environment{
        Sources: []interactions.Source{
            {
                Type:    interactions.SourceTypeInline.ToPointer(),
                Target:  genai.Ptr(".agents/AGENTS.md"),
                Content: genai.Ptr("Always use matplotlib for charts. Include a summary table in every report."),
            },
            {
                Type:    interactions.SourceTypeInline.ToPointer(),
                Target:  genai.Ptr(".agents/skills/slide-maker/SKILL.md"),
                Content: genai.Ptr("---\nname: slide-maker\n---\n# Slide Maker\nCreate HTML slide decks from data analysis results."),
            },
        },
    }

    res, err := client.Interactions.Create(ctx, operations.CreateInteractionRequest{
        Body: operations.NewCreateInteractionRequestBody(interactions.CreateAgentInteraction{
            Agent:             interactions.AgentOption("antigravity-preview-09-2026"),
            Input:             interactions.NewInteractionsInput("Analyze the Q1 revenue data and create a slide deck."),
            SystemInstruction: genai.Ptr("You are a data analyst. Always include visualizations and export results as PDF."),
            Environment:       genai.Ptr(interactions.NewCreateAgentInteractionEnvironment(env)),
        }),
    })
    if err != nil {
        log.Fatal(err)
    }
    if res.Interaction.OutputText != nil {
        fmt.Println(*res.Interaction.OutputText)
    }
}
```

```
curl -X POST "https://generativelanguage.googleapis.com/v1beta/interactions" \
-H "Content-Type: application/json" \
-H "x-goog-api-key: $GEMINI_API_KEY" \
-d '{
    "agent": "antigravity-preview-09-2026",
    "input": "Analyze the Q1 revenue data and create a slide deck.",
    "system_instruction": "You are a data analyst. Always include visualizations and export results as PDF.",
    "environment": {
        "type": "remote",
        "sources": [\
            {\
                "type": "inline",\
                "target": ".agents/AGENTS.md",\
                "content": "Always use matplotlib for charts. Include a summary table in every report."\
            },\
            {\
                "type": "inline",\
                "target": ".agents/skills/slide-maker/SKILL.md",\
                "content": "---\nname: slide-maker\n---\n# Slide Maker\nCreate HTML slide decks from data analysis results."\
            }\
        ]
    }
}'
```

Everything is defined at interaction time. No need to register anything first. The Antigravity agent harness provides the runtime (code execution, file management, web access) and your configuration layers on top.

### Tools and system instructions

You can customize the agent's behavior and capabilities for a specific interaction using the `system_instruction` and `tools` parameters.

- **System instructions**: Use the `system_instruction` parameter to pass inline text that shapes the agent's behavior. This is ideal for quick tweaks you want to change per call. The `system_instruction` and `AGENTS.md` are additive; both apply when present.
- **Tools**: By default, the Antigravity agent has access to `code_execution`, `google_search`, and `url_context`. You can override this list by passing the `tools` parameter at interaction time. You can also register [remote MCP servers](https://ai.google.dev/gemini-api/docs/antigravity-agent#mcp-servers) or define [custom functions (function calling)](https://ai.google.dev/gemini-api/docs/antigravity-agent#function-calling) to connect the agent to your own APIs and databases. For full details on available tools, see [Antigravity Agent: Supported tools](https://ai.google.dev/gemini-api/docs/antigravity-agent#supported-tools).

### File-based customization

#### Agent directory structure

While you can pass configuration inline, we recommend organizing your agent's files in a structured directory. This makes it easier to manage, version control, and mount into the agent's environment.

A typical agent project directory looks like this:

```
my-agent/
├── AGENTS.md        # Instructions on how the agent should operate
├── skills/          # Custom skills (subfolders and SKILL.md files)
│   └── slide-maker/
│       └── SKILL.md
└── workspace/       # Initial data files and knowledge
```

The Antigravity runtime scans `.agents/` (and the root of the environment) for these files.

#### AGENTS.md

The agent automatically loads `.agents/AGENTS.md` (or `/.agents/AGENTS.md`) from the environment as system instructions on startup. Use `AGENTS.md` for long-form persona definitions, detailed guidelines, and instructions you want to version control alongside your code.

Mount an `AGENTS.md` using an inline source:

[Python](https://ai.google.dev/gemini-api/docs/custom-agents#python)[JavaScript](https://ai.google.dev/gemini-api/docs/custom-agents#javascript)[Java](https://ai.google.dev/gemini-api/docs/custom-agents#java)[Go](https://ai.google.dev/gemini-api/docs/custom-agents#go)[REST](https://ai.google.dev/gemini-api/docs/custom-agents#rest)More

```
from google import genai

client = genai.Client()

interaction = client.interactions.create(
    agent="antigravity-preview-09-2026",
    input="Analyze the Q1 revenue data and create a report.",
    system_instruction="You are a data analyst. Always include visualizations and export results as PDF.",
    environment={
        "type": "remote",
        "sources": [\
            {\
                "type": "inline",\
                "target": ".agents/AGENTS.md",\
                "content": "Always use matplotlib for charts. Include a summary table in every report.",\
            },\
        ],
    },
)

print(interaction.output_text)
```

```
import { GoogleGenAI } from "@google/genai";

const client = new GoogleGenAI({});

const interaction = await client.interactions.create({
    agent: "antigravity-preview-09-2026",
    input: "Analyze the Q1 revenue data and create a report.",
    system_instruction: "You are a data analyst. Always include visualizations and export results as PDF.",
    environment: {
        type: "remote",
        sources: [\
            {\
                type: "inline",\
                target: ".agents/AGENTS.md",\
                content: "Always use matplotlib for charts. Include a summary table in every report.",\
            },\
        ],
    },
}, { timeout: 300000 });

console.log(interaction.output_text);
```

```
import com.google.genai.Client;
import com.google.genai.gaos.models.interactions.AgentOption;
import com.google.genai.gaos.models.interactions.CreateAgentInteraction;
import com.google.genai.gaos.models.interactions.CreateAgentInteractionEnvironment;
import com.google.genai.gaos.models.interactions.Environment;
import com.google.genai.gaos.models.interactions.Interaction;
import com.google.genai.gaos.models.interactions.InteractionsInput;
import com.google.genai.gaos.models.interactions.Source;
import com.google.genai.gaos.models.interactions.SourceType;
import com.google.genai.gaos.models.operations.CreateInteractionRequestBody;
import java.util.List;

Client client = new Client();

Environment env = Environment.builder()
    .sources(List.of(
        Source.builder()
            .type(SourceType.INLINE)
            .target(".agents/AGENTS.md")
            .content("Always use matplotlib for charts. Include a summary table in every report.")
            .build()
    ))
    .build();

CreateAgentInteraction params = CreateAgentInteraction.builder()
    .agent(AgentOption.of("antigravity-preview-09-2026"))
    .input(InteractionsInput.of("Analyze the Q1 revenue data and create a report."))
    .systemInstruction("You are a data analyst. Always include visualizations and export results as PDF.")
    .environment(CreateAgentInteractionEnvironment.of(env))
    .build();

Interaction interaction = client.interactions.create(CreateInteractionRequestBody.of(params)).interaction().get();
System.out.println(interaction.outputText().orElse(""));
```

```
package main

import (
    "context"
    "fmt"
    "log"

    "google.golang.org/genai"
    "google.golang.org/genai/interactions/models/interactions"
    "google.golang.org/genai/interactions/models/operations"
)

func main() {
    ctx := context.Background()
    client, err := genai.NewClient(ctx, nil)
    if err != nil {
        log.Fatal(err)
    }

    env := interactions.Environment{
        Sources: []interactions.Source{
            {
                Type:    interactions.SourceTypeInline.ToPointer(),
                Target:  genai.Ptr(".agents/AGENTS.md"),
                Content: genai.Ptr("Always use matplotlib for charts. Include a summary table in every report."),
            },
        },
    }

    res, err := client.Interactions.Create(ctx, operations.CreateInteractionRequest{
        Body: operations.NewCreateInteractionRequestBody(interactions.CreateAgentInteraction{
            Agent:             interactions.AgentOption("antigravity-preview-09-2026"),
            Input:             interactions.NewInteractionsInput("Analyze the Q1 revenue data and create a report."),
            SystemInstruction: genai.Ptr("You are a data analyst. Always include visualizations and export results as PDF."),
            Environment:       genai.Ptr(interactions.NewCreateAgentInteractionEnvironment(env)),
        }),
    })
    if err != nil {
        log.Fatal(err)
    }
    if res.Interaction.OutputText != nil {
        fmt.Println(*res.Interaction.OutputText)
    }
}
```

```
curl -X POST "https://generativelanguage.googleapis.com/v1beta/interactions" \
  -H "Content-Type: application/json" \
  -H "x-goog-api-key: $GEMINI_API_KEY" \
  -d '{
      "agent": "antigravity-preview-09-2026",
      "input": "Analyze the Q1 revenue data and create a report.",
      "system_instruction": "You are a data analyst. Always include visualizations and export results as PDF.",
      "environment": {
          "type": "remote",
          "sources": [\
              {\
                  "type": "inline",\
                  "target": ".agents/AGENTS.md",\
                  "content": "Always use matplotlib for charts. Include a summary table in every report."\
              }\
          ]
      }
  }'
```

#### Skills: SKILL.md

Skills are files that extend the agent's capabilities. Place them under `.agents/skills/<skill-name>/SKILL.md` and the harness auto-discovers and registers them.

```
.agents/
├── AGENTS.md
└── skills/
    └── slide-maker/
        └── SKILL.md
```

Mount a skill using an inline source:

[Python](https://ai.google.dev/gemini-api/docs/custom-agents#python)[JavaScript](https://ai.google.dev/gemini-api/docs/custom-agents#javascript)[Java](https://ai.google.dev/gemini-api/docs/custom-agents#java)[Go](https://ai.google.dev/gemini-api/docs/custom-agents#go)[REST](https://ai.google.dev/gemini-api/docs/custom-agents#rest)More

```
from google import genai

client = genai.Client()

interaction = client.interactions.create(
    agent="antigravity-preview-09-2026",
    input="Create a presentation about our Q1 results.",
    system_instruction="You create presentations from data.",
    environment={
        "type": "remote",
        "sources": [\
            {\
                "type": "inline",\
                "target": ".agents/skills/slide-maker/SKILL.md",\
                "content": "---\nname: slide-maker\ndescription: Create HTML slide decks\n---\n# Slide Maker\n\nWhen asked to create a presentation:\n1. Analyze the input data\n2. Create an HTML slide deck with reveal.js\n3. Save to /workspace/output/slides.html",\
            },\
        ],
    },
)

print(interaction.output_text)
```

```
import { GoogleGenAI } from "@google/genai";

const client = new GoogleGenAI({});

const interaction = await client.interactions.create({
    agent: "antigravity-preview-09-2026",
    input: "Create a presentation about our Q1 results.",
    system_instruction: "You create presentations from data.",
    environment: {
        type: "remote",
        sources: [\
            {\
                type: "inline",\
                target: ".agents/skills/slide-maker/SKILL.md",\
                content: "---\nname: slide-maker\ndescription: Create HTML slide decks\n---\n# Slide Maker\n\nWhen asked to create a presentation:\n1. Analyze the input data\n2. Create an HTML slide deck with reveal.js\n3. Save to /workspace/output/slides.html",\
            },\
        ],
    },
}, { timeout: 300000 });

console.log(interaction.output_text);
```

```
import com.google.genai.Client;
import com.google.genai.gaos.models.interactions.AgentOption;
import com.google.genai.gaos.models.interactions.CreateAgentInteraction;
import com.google.genai.gaos.models.interactions.CreateAgentInteractionEnvironment;
import com.google.genai.gaos.models.interactions.Environment;
import com.google.genai.gaos.models.interactions.Interaction;
import com.google.genai.gaos.models.interactions.InteractionsInput;
import com.google.genai.gaos.models.interactions.Source;
import com.google.genai.gaos.models.interactions.SourceType;
import com.google.genai.gaos.models.operations.CreateInteractionRequestBody;
import java.util.List;

Client client = new Client();

Environment env = Environment.builder()
    .sources(List.of(
        Source.builder()
            .type(SourceType.INLINE)
            .target(".agents/skills/slide-maker/SKILL.md")
            .content("---\nname: slide-maker\ndescription: Create HTML slide decks\n---\n# Slide Maker\n\nWhen asked to create a presentation:\n1. Analyze the input data\n2. Create an HTML slide deck with reveal.js\n3. Save to /workspace/output/slides.html")
            .build()
    ))
    .build();

CreateAgentInteraction params = CreateAgentInteraction.builder()
    .agent(AgentOption.of("antigravity-preview-09-2026"))
    .input(InteractionsInput.of("Create a presentation about our Q1 results."))
    .systemInstruction("You create presentations from data.")
    .environment(CreateAgentInteractionEnvironment.of(env))
    .build();

Interaction interaction = client.interactions.create(CreateInteractionRequestBody.of(params)).interaction().get();
System.out.println(interaction.outputText().orElse(""));
```

```
package main

import (
    "context"
    "fmt"
    "log"

    "google.golang.org/genai"
    "google.golang.org/genai/interactions/models/interactions"
    "google.golang.org/genai/interactions/models/operations"
)

func main() {
    ctx := context.Background()
    client, err := genai.NewClient(ctx, nil)
    if err != nil {
        log.Fatal(err)
    }

    env := interactions.Environment{
        Sources: []interactions.Source{
            {
                Type:    interactions.SourceTypeInline.ToPointer(),
                Target:  genai.Ptr(".agents/skills/slide-maker/SKILL.md"),
                Content: genai.Ptr("---\nname: slide-maker\ndescription: Create HTML slide decks\n---\n# Slide Maker\n\nWhen asked to create a presentation:\n1. Analyze the input data\n2. Create an HTML slide deck with reveal.js\n3. Save to /workspace/output/slides.html"),
            },
        },
    }

    res, err := client.Interactions.Create(ctx, operations.CreateInteractionRequest{
        Body: operations.NewCreateInteractionRequestBody(interactions.CreateAgentInteraction{
            Agent:             interactions.AgentOption("antigravity-preview-09-2026"),
            Input:             interactions.NewInteractionsInput("Create a presentation about our Q1 results."),
            SystemInstruction: genai.Ptr("You create presentations from data."),
            Environment:       genai.Ptr(interactions.NewCreateAgentInteractionEnvironment(env)),
        }),
    })
    if err != nil {
        log.Fatal(err)
    }
    if res.Interaction.OutputText != nil {
        fmt.Println(*res.Interaction.OutputText)
    }
}
```

```
curl -X POST "https://generativelanguage.googleapis.com/v1beta/interactions" \
  -H "Content-Type: application/json" \
  -H "x-goog-api-key: $GEMINI_API_KEY" \
  -d '{
      "agent": "antigravity-preview-09-2026",
      "input": "Create a presentation about our Q1 results.",
      "system_instruction": "You create presentations from data.",
      "environment": {
          "type": "remote",
          "sources": [\
              {\
                  "type": "inline",\
                  "target": ".agents/skills/slide-maker/SKILL.md",\
                  "content": "---\nname: slide-maker\ndescription: Create HTML slide decks\n---\n# Slide Maker\n\nWhen asked to create a presentation:\n1. Analyze the input data\n2. Create an HTML slide deck with reveal.js\n3. Save to /workspace/output/slides.html"\
              }\
          ]
      }
  }'
```

Skills loaded from `.agents/skills/` and `/.agents/skills/` are both discovered automatically.

## Create a managed agent

Once you've iterated on your configuration, you can create it as a managed agent with `agents.create`. This lets you invoke the agent by ID without repeating the configuration each time.

The `id` you specify when creating a managed agent must be unique to your project and must not start with reserved prefixes (e.g., `google-`, `gemini-`). See [Agent ID restrictions](https://ai.google.dev/gemini-api/docs/custom-agents#agent-id-restrictions) for the full list of restricted prefixes.

### From sources

Specify `base_agent`, `id`, `agent_config`, `system_instruction` and `base_environment` with sources. The platform provisions a fresh sandbox with your files on every invocation. See [Environments](https://ai.google.dev/gemini-api/docs/agent-environment) for available source types (Git, GCS, inline).

[Python](https://ai.google.dev/gemini-api/docs/custom-agents#python)[JavaScript](https://ai.google.dev/gemini-api/docs/custom-agents#javascript)[Java](https://ai.google.dev/gemini-api/docs/custom-agents#java)[Go](https://ai.google.dev/gemini-api/docs/custom-agents#go)[REST](https://ai.google.dev/gemini-api/docs/custom-agents#rest)More

```
from google import genai

client = genai.Client()

agent = client.agents.create(
    id="data-analyst",
    base_agent="antigravity-preview-09-2026",
    agent_config={
        "type": "antigravity",
        "model": "gemini-3.8-flash",
    },
    system_instruction="You are a data analyst. Always include visualizations and export results as PDF.",
    base_environment={
        "type": "remote",
        "sources": [\
            {\
                "type": "inline",\
                "target": ".agents/AGENTS.md",\
                "content": "Always use matplotlib for charts. Include a summary table in every report.",\
            },\
            {\
                "type": "inline",\
                "target": ".agents/skills/slide-maker/SKILL.md",\
                "content": "---\nname: slide-maker\n---\n# Slide Maker\nCreate HTML slide decks from data analysis results.",\
            },\
            {\
                "type": "repository",\
                "source": "https://github.com/my-org/analysis-templates",\
                "target": "/workspace/templates",\
            },\
        ],
    },
)

print(f"Created agent: {agent.id}")
```

```
import { GoogleGenAI } from "@google/genai";

const client = new GoogleGenAI({});

const agent = await client.agents.create({
    id: "data-analyst",
    base_agent: "antigravity-preview-09-2026",
    agent_config: {
        type: "antigravity",
        model: "gemini-3.8-flash",
    },
    system_instruction: "You are a data analyst. Always include visualizations and export results as PDF.",
    base_environment: {
        type: "remote",
        sources: [\
            {\
                type: "inline",\
                target: ".agents/AGENTS.md",\
                content: "Always use matplotlib for charts. Include a summary table in every report.",\
            },\
            {\
                type: "inline",\
                target: ".agents/skills/slide-maker/SKILL.md",\
                content: "---\nname: slide-maker\n---\n# Slide Maker\nCreate HTML slide decks from data analysis results.",\
            },\
            {\
                type: "repository",\
                source: "https://github.com/my-org/analysis-templates",\
                target: "/workspace/templates",\
            },\
        ],
    },
});

console.log(`Created agent: ${agent.id}`);
```

```
import com.google.genai.Client;
import com.google.genai.gaos.models.agents.Agent;
import com.google.genai.gaos.models.agents.AgentConfig;
import com.google.genai.gaos.models.agents.BaseEnvironment;
import com.google.genai.gaos.models.interactions.AntigravityAgentConfig;
import com.google.genai.gaos.models.interactions.Environment;
import com.google.genai.gaos.models.interactions.Source;
import com.google.genai.gaos.models.interactions.SourceType;
import java.util.List;

Client client = new Client();

Environment env = Environment.builder()
    .sources(List.of(
        Source.builder()
            .type(SourceType.INLINE)
            .target(".agents/AGENTS.md")
            .content("Always use matplotlib for charts. Include a summary table in every report.")
            .build(),
        Source.builder()
            .type(SourceType.INLINE)
            .target(".agents/skills/slide-maker/SKILL.md")
            .content("---\nname: slide-maker\n---\n# Slide Maker\nCreate HTML slide decks from data analysis results.")
            .build(),
        Source.builder()
            .type(SourceType.REPOSITORY)
            .source("https://github.com/my-org/analysis-templates")
            .target("/workspace/templates")
            .build()
    ))
    .build();

Agent agentParams = Agent.builder()
    .id("data-analyst")
    .baseAgent("antigravity-preview-09-2026")
    .agentConfig(AgentConfig.of(
        AntigravityAgentConfig.builder()
            .model("gemini-3.8-flash")
            .build()
    ))
    .systemInstruction("You are a data analyst. Always include visualizations and export results as PDF.")
    .baseEnvironment(BaseEnvironment.of(env))
    .build();

Agent agent = client.agents.create(agentParams).agent().get();
System.out.println("Created agent: " + agent.id().orElse(""));
```

```
package main

import (
    "context"
    "fmt"
    "log"

    "google.golang.org/genai"
    "google.golang.org/genai/interactions/models/agents"
    "google.golang.org/genai/interactions/models/interactions"
    "google.golang.org/genai/interactions/models/operations"
)

func main() {
    ctx := context.Background()
    client, err := genai.NewClient(ctx, nil)
    if err != nil {
        log.Fatal(err)
    }

    env := interactions.Environment{
        Sources: []interactions.Source{
            {
                Type:    interactions.SourceTypeInline.ToPointer(),
                Target:  genai.Ptr(".agents/AGENTS.md"),
                Content: genai.Ptr("Always use matplotlib for charts. Include a summary table in every report."),
            },
            {
                Type:    interactions.SourceTypeInline.ToPointer(),
                Target:  genai.Ptr(".agents/skills/slide-maker/SKILL.md"),
                Content: genai.Ptr("---\nname: slide-maker\n---\n# Slide Maker\nCreate HTML slide decks from data analysis results."),
            },
            {
                Type:   interactions.SourceTypeRepository.ToPointer(),
                Source: genai.Ptr("https://github.com/my-org/analysis-templates"),
                Target: genai.Ptr("/workspace/templates"),
            },
        },
    }

    res, err := client.Agents.Create(ctx, operations.CreateAgentRequest{
        Body: agents.Agent{
            ID:        genai.Ptr("data-analyst"),
            BaseAgent: genai.Ptr("antigravity-preview-09-2026"),
            AgentConfig: genai.Ptr(agents.NewAgentConfig(interactions.AntigravityAgentConfig{
                Model: genai.Ptr("gemini-3.8-flash"),
            })),
            SystemInstruction: genai.Ptr("You are a data analyst. Always include visualizations and export results as PDF."),
            BaseEnvironment:   genai.Ptr(agents.NewBaseEnvironment(env)),
        },
    })
    if err != nil {
        log.Fatal(err)
    }

    fmt.Printf("Created agent: %s\n", *res.Agent.ID)
}
```

```
curl -X POST "https://generativelanguage.googleapis.com/v1beta/agents" \
-H "Content-Type: application/json" \
-H "x-goog-api-key: $GEMINI_API_KEY" \
-d '{
    "id": "data-analyst",
    "base_agent": "antigravity-preview-09-2026",
    "agent_config": {
        "type": "antigravity",
        "model": "gemini-3.8-flash"
    },
    "system_instruction": "You are a data analyst. Always include visualizations and export results as PDF.",
    "base_environment": {
        "type": "remote",
        "sources": [\
            {\
                "type": "inline",\
                "target": ".agents/AGENTS.md",\
                "content": "Always use matplotlib for charts. Include a summary table in every report."\
            },\
            {\
                "type": "inline",\
                "target": ".agents/skills/slide-maker/SKILL.md",\
                "content": "---\nname: slide-maker\n---\n# Slide Maker\nCreate HTML slide decks from data analysis results."\
            },\
            {\
                "type": "repository",\
                "source": "https://github.com/my-org/analysis-templates",\
                "target": "/workspace/templates"\
            }\
        ]
    }
}'
```

### From an existing environment (fork)

Iterate with the base Antigravity agent until the environment is right (packages installed, files in place), then fork it into a managed agent.

[Python](https://ai.google.dev/gemini-api/docs/custom-agents#python)[JavaScript](https://ai.google.dev/gemini-api/docs/custom-agents#javascript)[Java](https://ai.google.dev/gemini-api/docs/custom-agents#java)[Go](https://ai.google.dev/gemini-api/docs/custom-agents#go)[REST](https://ai.google.dev/gemini-api/docs/custom-agents#rest)More

```
from google import genai

client = genai.Client()

# Step 1: set up the environment interactively
interaction = client.interactions.create(
    agent="antigravity-preview-09-2026",
    input="Install pandas, matplotlib, and seaborn. Create an analysis template at /workspace/template.py.",
    environment="remote",
)

# Step 2: fork that environment into a managed agent

agent = client.agents.create(
    id="my-data-analyst",
    base_agent="antigravity-preview-09-2026",
    system_instruction="You are a data analyst. Use the template at /workspace/template.py for all reports.",
    base_environment=interaction.environment_id,
)

print(f"Forked agent successfully: {agent.id}")
```

```
import { GoogleGenAI } from "@google/genai";

const client = new GoogleGenAI({});

const interaction = await client.interactions.create({
    agent: "antigravity-preview-09-2026",
    input: "Install pandas, matplotlib, and seaborn. Create an analysis template at /workspace/template.py.",
    environment: "remote",
}, { timeout: 300000 });

const agent = await client.agents.create({
    id: "my-data-analyst",
    base_agent: "antigravity-preview-09-2026",
    system_instruction: "You are a data analyst. Use the template at /workspace/template.py for all reports.",
    base_environment: interaction.environment_id,
});

console.log(`Forked agent successfully: ${agent.id}`);
```

```
import com.google.genai.Client;
import com.google.genai.gaos.models.agents.Agent;
import com.google.genai.gaos.models.agents.BaseEnvironment;
import com.google.genai.gaos.models.interactions.AgentOption;
import com.google.genai.gaos.models.interactions.CreateAgentInteraction;
import com.google.genai.gaos.models.interactions.CreateAgentInteractionEnvironment;
import com.google.genai.gaos.models.interactions.Interaction;
import com.google.genai.gaos.models.interactions.InteractionsInput;
import com.google.genai.gaos.models.operations.CreateInteractionRequestBody;

Client client = new Client();

// Step 1: set up the environment interactively
CreateAgentInteraction params = CreateAgentInteraction.builder()
    .agent(AgentOption.of("antigravity-preview-09-2026"))
    .input(InteractionsInput.of("Install pandas, matplotlib, and seaborn. Create an analysis template at /workspace/template.py."))
    .environment(CreateAgentInteractionEnvironment.of("remote"))
    .build();

Interaction interaction = client.interactions.create(CreateInteractionRequestBody.of(params)).interaction().get();

// Step 2: fork that environment into a managed agent
Agent agentParams = Agent.builder()
    .id("my-data-analyst")
    .baseAgent("antigravity-preview-09-2026")
    .systemInstruction("You are a data analyst. Use the template at /workspace/template.py for all reports.")
    .baseEnvironment(BaseEnvironment.of(interaction.environmentId().orElse("")))
    .build();

Agent agent = client.agents.create(agentParams).agent().get();
System.out.println("Forked agent successfully: " + agent.id().orElse(""));
```

```
package main

import (
    "context"
    "fmt"
    "log"

    "google.golang.org/genai"
    "google.golang.org/genai/interactions/models/agents"
    "google.golang.org/genai/interactions/models/interactions"
    "google.golang.org/genai/interactions/models/operations"
)

func main() {
    ctx := context.Background()
    client, err := genai.NewClient(ctx, nil)
    if err != nil {
        log.Fatal(err)
    }

    // Step 1: set up the environment interactively
    intRes, err := client.Interactions.Create(ctx, operations.CreateInteractionRequest{
        Body: operations.NewCreateInteractionRequestBody(interactions.CreateAgentInteraction{
            Agent:       interactions.AgentOption("antigravity-preview-09-2026"),
            Input:       interactions.NewInteractionsInput("Install pandas, matplotlib, and seaborn. Create an analysis template at /workspace/template.py."),
            Environment: genai.Ptr(interactions.NewCreateAgentInteractionEnvironment("remote")),
        }),
    })
    if err != nil {
        log.Fatal(err)
    }
    interaction := intRes.Interaction

    // Step 2: fork that environment into a managed agent
    agentRes, err := client.Agents.Create(ctx, operations.CreateAgentRequest{
        Body: agents.Agent{
            ID:                genai.Ptr("my-data-analyst"),
            BaseAgent:         genai.Ptr("antigravity-preview-09-2026"),
            SystemInstruction: genai.Ptr("You are a data analyst. Use the template at /workspace/template.py for all reports."),
            BaseEnvironment:   genai.Ptr(agents.NewBaseEnvironment(*interaction.EnvironmentID)),
        },
    })
    if err != nil {
        log.Fatal(err)
    }

    fmt.Printf("Forked agent successfully: %s\n", *agentRes.Agent.ID)
}
```

```
curl -X POST "https://generativelanguage.googleapis.com/v1beta/interactions" \
  -H "Content-Type: application/json" \
  -H "x-goog-api-key: $GEMINI_API_KEY" \
  -d '{
      "agent": "antigravity-preview-09-2026",
      "input": "Install pandas, matplotlib, and seaborn. Create an analysis template at /workspace/template.py.",
      "environment": "remote"
  }'
```

### With network rules

You can lock down outbound access or inject credentials when saving a managed agent. For the full allowlist schema, credential patterns, and wildcards, see [Environments: Network configuration](https://ai.google.dev/gemini-api/docs/agent-environment#network-configuration).

Reference a stored [credential](https://ai.google.dev/gemini-api/docs/agent-credentials) by ID on an allowlist rule (`"credential": "github-production"`) and the egress proxy injects the secret at request time, so it never lands in your agent definition. This example sets the header inline with `transform` instead. The proxy applies both forms the same way, a credential additionally lets you reuse the secret across agents and rotate it in one place.

The following example creates an `issue-resolver` agent that can only access GitHub and PyPI, with credentials injected for GitHub:

[Python](https://ai.google.dev/gemini-api/docs/custom-agents#python)[JavaScript](https://ai.google.dev/gemini-api/docs/custom-agents#javascript)[Java](https://ai.google.dev/gemini-api/docs/custom-agents#java)[Go](https://ai.google.dev/gemini-api/docs/custom-agents#go)[REST](https://ai.google.dev/gemini-api/docs/custom-agents#rest)More

```
from google import genai

client = genai.Client()

agent = client.agents.create(
    id="issue-resolver",
    base_agent="antigravity-preview-09-2026",
    system_instruction="You resolve GitHub issues. Clone the repo, find the bug, write the fix, run the tests, and open a PR.",
    base_environment={
        "type": "remote",
        "sources": [\
            {\
                "type": "repository",\
                "source": "https://github.com/my-org/backend",\
                "target": "/workspace/repo",\
            }\
        ],
        "network": {
            "allowlist": [\
                {\
                    "domain": "api.github.com",\
                    "transform": {\
                        "Authorization": "Basic YOUR_BASE64_TOKEN"\
                    },\
                },\
                {"domain": "pypi.org"},\
            ]
        },
    },
)

print(f"Created issue-resolver agent successfully: {agent.id}")
```

```
import { GoogleGenAI } from "@google/genai";

const client = new GoogleGenAI({});

const agent = await client.agents.create({
    id: "issue-resolver",
    base_agent: "antigravity-preview-09-2026",
    system_instruction: "You resolve GitHub issues. Clone the repo, find the bug, write the fix, run the tests, and open a PR.",
    base_environment: {
        type: "remote",
        sources: [\
            {\
                type: "repository",\
                source: "https://github.com/my-org/backend",\
                target: "/workspace/repo",\
            }\
        ],
        network: {
            allowlist: [\
                {\
                    domain: "api.github.com",\
                    transform: {\
                        "Authorization": "Basic YOUR_BASE64_TOKEN"\
                    },\
                },\
                { domain: "pypi.org" },\
            ]
        }
    },
});

console.log(`Created issue-resolver agent successfully: ${agent.id}`);
```

```
import com.google.genai.Client;
import com.google.genai.gaos.models.agents.Agent;
import com.google.genai.gaos.models.agents.BaseEnvironment;
import com.google.genai.gaos.models.interactions.Allowlist;
import com.google.genai.gaos.models.interactions.AllowlistEntry;
import com.google.genai.gaos.models.interactions.Environment;
import com.google.genai.gaos.models.interactions.EnvironmentNetworkEgressAllowlist;
import com.google.genai.gaos.models.interactions.Network;
import com.google.genai.gaos.models.interactions.Source;
import com.google.genai.gaos.models.interactions.SourceType;
import com.google.genai.gaos.models.interactions.Transform;
import java.util.List;
import java.util.Map;

Client client = new Client();

Environment env = Environment.builder()
    .sources(List.of(
        Source.builder()
            .type(SourceType.REPOSITORY)
            .source("https://github.com/my-org/backend")
            .target("/workspace/repo")
            .build()
    ))
    .network(Network.of(
        EnvironmentNetworkEgressAllowlist.builder()
            .allowlist(Allowlist.of(List.of(
                AllowlistEntry.builder()
                    .domain("api.github.com")
                    .transform(Transform.of(Map.of(
                        "Authorization", "Basic YOUR_BASE64_TOKEN"
                    )))
                    .build(),
                AllowlistEntry.builder().domain("pypi.org").build()
            )))
            .build()
    ))
    .build();

Agent agentParams = Agent.builder()
    .id("issue-resolver")
    .baseAgent("antigravity-preview-09-2026")
    .systemInstruction("You resolve GitHub issues. Clone the repo, find the bug, write the fix, run the tests, and open a PR.")
    .baseEnvironment(BaseEnvironment.of(env))
    .build();

Agent agent = client.agents.create(agentParams).agent().get();
System.out.println("Created issue-resolver agent successfully: " + agent.id().orElse(""));
```

```
package main

import (
    "context"
    "fmt"
    "log"

    "google.golang.org/genai"
    "google.golang.org/genai/interactions/models/agents"
    "google.golang.org/genai/interactions/models/interactions"
    "google.golang.org/genai/interactions/models/operations"
)

func main() {
    ctx := context.Background()
    client, err := genai.NewClient(ctx, nil)
    if err != nil {
        log.Fatal(err)
    }

    env := interactions.Environment{
        Sources: []interactions.Source{
            {
                Type:   interactions.SourceTypeRepository.ToPointer(),
                Source: genai.Ptr("https://github.com/my-org/backend"),
                Target: genai.Ptr("/workspace/repo"),
            },
        },
        Network: genai.Ptr(interactions.NewNetwork(interactions.EnvironmentNetworkEgressAllowlist{
            Allowlist: genai.Ptr(interactions.NewAllowlist([]interactions.AllowlistEntry{
                {
                    Domain: "api.github.com",
                    Transform: genai.Ptr(interactions.NewTransform(map[string]string{
                        "Authorization": "Basic YOUR_BASE64_TOKEN",
                    })),
                },
                {
                    Domain: "pypi.org",
                },
            })),
        })),
    }

    res, err := client.Agents.Create(ctx, operations.CreateAgentRequest{
        Body: agents.Agent{
            ID:                genai.Ptr("issue-resolver"),
            BaseAgent:         genai.Ptr("antigravity-preview-09-2026"),
            SystemInstruction: genai.Ptr("You resolve GitHub issues. Clone the repo, find the bug, write the fix, run the tests, and open a PR."),
            BaseEnvironment:   genai.Ptr(agents.NewBaseEnvironment(env)),
        },
    })
    if err != nil {
        log.Fatal(err)
    }

    fmt.Printf("Created issue-resolver agent successfully: %s\n", *res.Agent.ID)
}
```

```
curl -X POST "https://generativelanguage.googleapis.com/v1beta/agents" \
  -H "Content-Type: application/json" \
  -H "x-goog-api-key: $GEMINI_API_KEY" \
  -d '{
      "id": "issue-resolver",
      "base_agent": "antigravity-preview-09-2026",
      "system_instruction": "You resolve GitHub issues. Clone the repo, find the bug, write the fix, run the tests, and open a PR.",
      "base_environment": {
          "type": "remote",
          "sources": [\
              {\
                  "type": "repository",\
                  "source": "https://github.com/my-org/backend",\
                  "target": "/workspace/repo"\
              }\
          ],
          "network": {
              "allowlist": [\
                  {\
                      "domain": "api.github.com",\
                      "transform": {\
                          "Authorization": "Basic YOUR_BASE64_TOKEN"\
                      }\
                  },\
                  {"domain": "pypi.org"}\
              ]
          }
      }
  }'
```

## Invoke the agent

Call your managed agent with your agent ID by creating a new interaction. Each invocation forks the base environment, so every run starts clean.

[Python](https://ai.google.dev/gemini-api/docs/custom-agents#python)[JavaScript](https://ai.google.dev/gemini-api/docs/custom-agents#javascript)[Java](https://ai.google.dev/gemini-api/docs/custom-agents#java)[Go](https://ai.google.dev/gemini-api/docs/custom-agents#go)[REST](https://ai.google.dev/gemini-api/docs/custom-agents#rest)More

```
result = client.interactions.create(
    agent="data-analyst",
    input="Analyze Q1 revenue data from /workspace/templates/sample.csv and create a slide deck.",
    environment="remote",
)

print(result.output_text)
```

```
const result = await client.interactions.create({
    agent: "data-analyst",
    input: "Analyze Q1 revenue data from /workspace/templates/sample.csv and create a slide deck.",
    environment: "remote",
}, { timeout: 300000 });

console.log(result.output_text);
```

```
import com.google.genai.Client;
import com.google.genai.gaos.models.interactions.AgentOption;
import com.google.genai.gaos.models.interactions.CreateAgentInteraction;
import com.google.genai.gaos.models.interactions.CreateAgentInteractionEnvironment;
import com.google.genai.gaos.models.interactions.Interaction;
import com.google.genai.gaos.models.interactions.InteractionsInput;
import com.google.genai.gaos.models.operations.CreateInteractionRequestBody;

Client client = new Client();

CreateAgentInteraction params = CreateAgentInteraction.builder()
    .agent(AgentOption.of("data-analyst"))
    .input(InteractionsInput.of("Analyze Q1 revenue data from /workspace/templates/sample.csv and create a slide deck."))
    .environment(CreateAgentInteractionEnvironment.of("remote"))
    .build();

Interaction result = client.interactions.create(CreateInteractionRequestBody.of(params)).interaction().get();
System.out.println(result.outputText().orElse(""));
```

```
package main

import (
    "context"
    "fmt"
    "log"

    "google.golang.org/genai"
    "google.golang.org/genai/interactions/models/interactions"
    "google.golang.org/genai/interactions/models/operations"
)

func main() {
    ctx := context.Background()
    client, err := genai.NewClient(ctx, nil)
    if err != nil {
        log.Fatal(err)
    }

    res, err := client.Interactions.Create(ctx, operations.CreateInteractionRequest{
        Body: operations.NewCreateInteractionRequestBody(interactions.CreateAgentInteraction{
            Agent:       interactions.AgentOption("data-analyst"),
            Input:       interactions.NewInteractionsInput("Analyze Q1 revenue data from /workspace/templates/sample.csv and create a slide deck."),
            Environment: genai.Ptr(interactions.NewCreateAgentInteractionEnvironment("remote")),
        }),
    })
    if err != nil {
        log.Fatal(err)
    }
    if res.Interaction.OutputText != nil {
        fmt.Println(*res.Interaction.OutputText)
    }
}
```

```
curl -X POST "https://generativelanguage.googleapis.com/v1beta/interactions" \
  -H "Content-Type: application/json" \
  -H "x-goog-api-key: $GEMINI_API_KEY" \
  -d '{
      "agent": "data-analyst",
      "input": "Analyze Q1 revenue data from /workspace/templates/sample.csv and create a slide deck.",
      "environment": "remote"
  }'
```

For multi-turn conversations and streaming, see the [Quickstart](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart). The same `previous_interaction_id` and `environment` patterns apply to managed agents.

Managed agents also support background execution and cancellation. For details and code examples, see [Antigravity Agent: Background execution](https://ai.google.dev/gemini-api/docs/antigravity-agent#background-execution).

## Overriding configuration at invocation

You can override the agent's default `system_instruction`, `tools`, and
`environment` network configuration when creating an interaction. This
lets you modify the agent's behavior, capabilities, or credentials for a
specific run without changing the stored agent definition.

### Override system instruction and tools

[Python](https://ai.google.dev/gemini-api/docs/custom-agents#python)[JavaScript](https://ai.google.dev/gemini-api/docs/custom-agents#javascript)[Java](https://ai.google.dev/gemini-api/docs/custom-agents#java)[Go](https://ai.google.dev/gemini-api/docs/custom-agents#go)[REST](https://ai.google.dev/gemini-api/docs/custom-agents#rest)More

```
result = client.interactions.create(
    agent="data-analyst",
    input="Analyze Q1 revenue data, but do not create a slide deck. Just output a summary table.",
    system_instruction="You are a data analyst. Focus ONLY on summary tables. Ignore default instructions about slides.",
    tools=[{"type": "code_execution"}], # Override to only use code execution
    environment="remote",
)
print(result.output_text)
```

```
const result = await client.interactions.create({
    agent: "data-analyst",
    input: "Analyze Q1 revenue data, but do not create a slide deck. Just output a summary table.",
    system_instruction: "You are a data analyst. Focus ONLY on summary tables. Ignore default instructions about slides.",
    tools: [{ type: "code_execution" }], // Override to only use code execution
    environment: "remote",
}, { timeout: 300000 });

console.log(result.output_text);
```

```
import com.google.genai.Client;
import com.google.genai.gaos.models.interactions.AgentOption;
import com.google.genai.gaos.models.interactions.CodeExecution;
import com.google.genai.gaos.models.interactions.CreateAgentInteraction;
import com.google.genai.gaos.models.interactions.CreateAgentInteractionEnvironment;
import com.google.genai.gaos.models.interactions.Interaction;
import com.google.genai.gaos.models.interactions.InteractionsInput;
import com.google.genai.gaos.models.operations.CreateInteractionRequestBody;
import java.util.List;

Client client = new Client();

CreateAgentInteraction params = CreateAgentInteraction.builder()
    .agent(AgentOption.of("data-analyst"))
    .input(InteractionsInput.of("Analyze Q1 revenue data, but do not create a slide deck. Just output a summary table."))
    .systemInstruction("You are a data analyst. Focus ONLY on summary tables. Ignore default instructions about slides.")
    .tools(List.of(CodeExecution.builder().build())) // Override to only use code execution
    .environment(CreateAgentInteractionEnvironment.of("remote"))
    .build();

Interaction result = client.interactions.create(CreateInteractionRequestBody.of(params)).interaction().get();
System.out.println(result.outputText().orElse(""));
```

```
package main

import (
    "context"
    "fmt"
    "log"

    "google.golang.org/genai"
    "google.golang.org/genai/interactions/models/interactions"
    "google.golang.org/genai/interactions/models/operations"
)

func main() {
    ctx := context.Background()
    client, err := genai.NewClient(ctx, nil)
    if err != nil {
        log.Fatal(err)
    }

    res, err := client.Interactions.Create(ctx, operations.CreateInteractionRequest{
        Body: operations.NewCreateInteractionRequestBody(interactions.CreateAgentInteraction{
            Agent:             interactions.AgentOption("data-analyst"),
            Input:             interactions.NewInteractionsInput("Analyze Q1 revenue data, but do not create a slide deck. Just output a summary table."),
            SystemInstruction: genai.Ptr("You are a data analyst. Focus ONLY on summary tables. Ignore default instructions about slides."),
            Tools:             []interactions.Tool{interactions.NewTool(interactions.CodeExecution{})}, // Override to only use code execution
            Environment:       genai.Ptr(interactions.NewCreateAgentInteractionEnvironment("remote")),
        }),
    })
    if err != nil {
        log.Fatal(err)
    }
    if res.Interaction.OutputText != nil {
        fmt.Println(*res.Interaction.OutputText)
    }
}
```

```
curl -X POST "https://generativelanguage.googleapis.com/v1beta/interactions" \
  -H "Content-Type: application/json" \
  -H "x-goog-api-key: $GEMINI_API_KEY" \
  -d '{
      "agent": "data-analyst",
      "input": "Analyze Q1 revenue data, but do not create a slide deck. Just output a summary table.",
      "system_instruction": "You are a data analyst. Focus ONLY on summary tables. Ignore default instructions about slides.",
      "tools": [{"type": "code_execution"}],
      "environment": "remote"
  }'
```

### Override network configuration (refresh credentials)

If your managed agent has network credentials baked into its `base_environment`,
you can override them at invocation time to refresh expired tokens or rotate API
keys. Pass an `environment` object with a new `network` configuration. The new
network rules fully replace the previous ones for that interaction. The base
environment's sources (files, repositories) are preserved.

If the `base_environment` references a stored
[credential](https://ai.google.dev/gemini-api/docs/agent-credentials) instead of an inline token, you
don't need to override anything. Rotate the credential with a `PATCH` and every
agent referencing it picks up the new secret on the next run.

[Python](https://ai.google.dev/gemini-api/docs/custom-agents#python)[JavaScript](https://ai.google.dev/gemini-api/docs/custom-agents#javascript)[Java](https://ai.google.dev/gemini-api/docs/custom-agents#java)[Go](https://ai.google.dev/gemini-api/docs/custom-agents#go)[REST](https://ai.google.dev/gemini-api/docs/custom-agents#rest)More

```
# Invoke the agent with a fresh token, overriding the base_environment credentials
result = client.interactions.create(
    agent="issue-resolver",
    input="Fix issue #42 and open a PR.",
    environment={
        "type": "remote",
        "network": {
            "allowlist": [\
                {\
                    "domain": "api.github.com",\
                    "transform": {\
                        "Authorization": "Bearer ghp_REFRESHED_TOKEN"\
                    },\
                },\
                {"domain": "pypi.org"},\
            ]
        },
    },
)

print(result.output_text)
```

```
// Invoke the agent with a fresh token, overriding the base_environment credentials
const result = await client.interactions.create({
    agent: "issue-resolver",
    input: "Fix issue #42 and open a PR.",
    environment: {
        type: "remote",
        network: {
            allowlist: [\
                {\
                    domain: "api.github.com",\
                    transform: {\
                        "Authorization": "Bearer ghp_REFRESHED_TOKEN"\
                    },\
                },\
                { domain: "pypi.org" },\
            ]
        },
    },
}, { timeout: 300000 });

console.log(result.output_text);
```

```
import com.google.genai.Client;
import com.google.genai.gaos.models.interactions.AgentOption;
import com.google.genai.gaos.models.interactions.Allowlist;
import com.google.genai.gaos.models.interactions.AllowlistEntry;
import com.google.genai.gaos.models.interactions.CreateAgentInteraction;
import com.google.genai.gaos.models.interactions.CreateAgentInteractionEnvironment;
import com.google.genai.gaos.models.interactions.Environment;
import com.google.genai.gaos.models.interactions.EnvironmentNetworkEgressAllowlist;
import com.google.genai.gaos.models.interactions.Interaction;
import com.google.genai.gaos.models.interactions.InteractionsInput;
import com.google.genai.gaos.models.interactions.Network;
import com.google.genai.gaos.models.interactions.Transform;
import com.google.genai.gaos.models.operations.CreateInteractionRequestBody;
import java.util.List;
import java.util.Map;

Client client = new Client();

// Invoke the agent with a fresh token, overriding the base_environment credentials
Environment env = Environment.builder()
    .network(Network.of(
        EnvironmentNetworkEgressAllowlist.builder()
            .allowlist(Allowlist.of(List.of(
                AllowlistEntry.builder()
                    .domain("api.github.com")
                    .transform(Transform.of(Map.of(
                        "Authorization", "Bearer ghp_REFRESHED_TOKEN"
                    )))
                    .build(),
                AllowlistEntry.builder().domain("pypi.org").build()
            )))
            .build()
    ))
    .build();

CreateAgentInteraction params = CreateAgentInteraction.builder()
    .agent(AgentOption.of("issue-resolver"))
    .input(InteractionsInput.of("Fix issue #42 and open a PR."))
    .environment(CreateAgentInteractionEnvironment.of(env))
    .build();

Interaction result = client.interactions.create(CreateInteractionRequestBody.of(params)).interaction().get();
System.out.println(result.outputText().orElse(""));
```

```
package main

import (
    "context"
    "fmt"
    "log"

    "google.golang.org/genai"
    "google.golang.org/genai/interactions/models/interactions"
    "google.golang.org/genai/interactions/models/operations"
)

func main() {
    ctx := context.Background()
    client, err := genai.NewClient(ctx, nil)
    if err != nil {
        log.Fatal(err)
    }

    // Invoke the agent with a fresh token, overriding the base_environment credentials
    env := interactions.Environment{
        Network: genai.Ptr(interactions.NewNetwork(interactions.EnvironmentNetworkEgressAllowlist{
            Allowlist: genai.Ptr(interactions.NewAllowlist([]interactions.AllowlistEntry{
                {
                    Domain: "api.github.com",
                    Transform: genai.Ptr(interactions.NewTransform(map[string]string{
                        "Authorization": "Bearer ghp_REFRESHED_TOKEN",
                    })),
                },
                {
                    Domain: "pypi.org",
                },
            })),
        })),
    }

    res, err := client.Interactions.Create(ctx, operations.CreateInteractionRequest{
        Body: operations.NewCreateInteractionRequestBody(interactions.CreateAgentInteraction{
            Agent:       interactions.AgentOption("issue-resolver"),
            Input:       interactions.NewInteractionsInput("Fix issue #42 and open a PR."),
            Environment: genai.Ptr(interactions.NewCreateAgentInteractionEnvironment(env)),
        }),
    })
    if err != nil {
        log.Fatal(err)
    }
    if res.Interaction.OutputText != nil {
        fmt.Println(*res.Interaction.OutputText)
    }
}
```

```
curl -X POST "https://generativelanguage.googleapis.com/v1beta/interactions" \
  -H "Content-Type: application/json" \
  -H "x-goog-api-key: $GEMINI_API_KEY" \
  -d '{
      "agent": "issue-resolver",
      "input": "Fix issue #42 and open a PR.",
      "environment": {
          "type": "remote",
          "network": {
              "allowlist": [\
                  {\
                      "domain": "api.github.com",\
                      "transform": {\
                          "Authorization": "Bearer ghp_REFRESHED_TOKEN"\
                      }\
                  },\
                  {"domain": "pypi.org"}\
              ]
          }
      }
  }'
```

## Manage agents

You can list, get, and delete agents.

### List agents

[Python](https://ai.google.dev/gemini-api/docs/custom-agents#python)[JavaScript](https://ai.google.dev/gemini-api/docs/custom-agents#javascript)[Java](https://ai.google.dev/gemini-api/docs/custom-agents#java)[Go](https://ai.google.dev/gemini-api/docs/custom-agents#go)[REST](https://ai.google.dev/gemini-api/docs/custom-agents#rest)More

```
agents = client.agents.list()
for a in agents.agents:
    print(f"{a.id}: {a.description}")
```

```
const agents = await client.agents.list();
if (agents.agents) {
    for (const a of agents.agents) {
        console.log(`${a.id}: ${a.description}`);
    }
}
```

```
import com.google.genai.Client;
import com.google.genai.gaos.models.agents.Agent;
import java.util.List;

Client client = new Client();

List<Agent> agents = client.agents.listDirect().agentListResponse().get().agents().orElse(List.of());
for (Agent a : agents) {
    System.out.println(a.id().orElse("") + ": " + a.description().orElse(""));
}
```

```
package main

import (
    "context"
    "fmt"
    "log"

    "google.golang.org/genai"
    "google.golang.org/genai/interactions/models/operations"
)

func main() {
    ctx := context.Background()
    client, err := genai.NewClient(ctx, nil)
    if err != nil {
        log.Fatal(err)
    }

    res, err := client.Agents.List(ctx, operations.ListAgentsRequest{})
    if err != nil {
        log.Fatal(err)
    }

    if res.AgentListResponse != nil {
        for _, a := range res.AgentListResponse.Agents {
            fmt.Printf("%s: %v\n", *a.ID, a.Description)
        }
    }
}
```

```
curl -X GET "https://generativelanguage.googleapis.com/v1beta/agents" \
  -H "x-goog-api-key: $GEMINI_API_KEY"
```

### Get an agent

[Python](https://ai.google.dev/gemini-api/docs/custom-agents#python)[JavaScript](https://ai.google.dev/gemini-api/docs/custom-agents#javascript)[Java](https://ai.google.dev/gemini-api/docs/custom-agents#java)[Go](https://ai.google.dev/gemini-api/docs/custom-agents#go)[REST](https://ai.google.dev/gemini-api/docs/custom-agents#rest)More

```
agent = client.agents.get(id="data-analyst")
print(agent)
```

```
const agent = await client.agents.get("data-analyst");
console.log(agent);
```

```
import com.google.genai.Client;
import com.google.genai.gaos.models.agents.Agent;

Client client = new Client();

Agent agent = client.agents.get("data-analyst").agent().get();
System.out.println(agent);
```

```
package main

import (
    "context"
    "fmt"
    "log"

    "google.golang.org/genai"
    "google.golang.org/genai/interactions/models/operations"
)

func main() {
    ctx := context.Background()
    client, err := genai.NewClient(ctx, nil)
    if err != nil {
        log.Fatal(err)
    }

    res, err := client.Agents.Get(ctx, operations.GetAgentRequest{
        ID: "data-analyst",
    })
    if err != nil {
        log.Fatal(err)
    }

    fmt.Printf("%+v\n", res.Agent)
}
```

```
curl -X GET "https://generativelanguage.googleapis.com/v1beta/agents/data-analyst" \
  -H "x-goog-api-key: $GEMINI_API_KEY"
```

### Delete an agent

Deleting removes the configuration. Existing environments and interactions created by the agent are not affected.

[Python](https://ai.google.dev/gemini-api/docs/custom-agents#python)[JavaScript](https://ai.google.dev/gemini-api/docs/custom-agents#javascript)[Java](https://ai.google.dev/gemini-api/docs/custom-agents#java)[Go](https://ai.google.dev/gemini-api/docs/custom-agents#go)[REST](https://ai.google.dev/gemini-api/docs/custom-agents#rest)More

```
client.agents.delete(id="data-analyst")
```

```
await client.agents.delete("data-analyst");
```

```
import com.google.genai.Client;

Client client = new Client();

client.agents.delete("data-analyst");
```

```
package main

import (
    "context"
    "log"

    "google.golang.org/genai"
    "google.golang.org/genai/interactions/models/operations"
)

func main() {
    ctx := context.Background()
    client, err := genai.NewClient(ctx, nil)
    if err != nil {
        log.Fatal(err)
    }

    _, err = client.Agents.Delete(ctx, operations.DeleteAgentRequest{
        ID: "data-analyst",
    })
    if err != nil {
        log.Fatal(err)
    }
}
```

```
curl -X DELETE "https://generativelanguage.googleapis.com/v1beta/agents/data-analyst" \
  -H "x-goog-api-key: $GEMINI_API_KEY"
```

## Agent definition reference

| Field | Type | Required | Description |
| --- | --- | --- | --- |
| `id` | string | Yes | Unique agent identifier within the Google Cloud project. Used to invoke the agent. Must not use reserved prefixes. See [Agent ID restrictions](https://ai.google.dev/gemini-api/docs/custom-agents#agent-id-restrictions). |
| `description` | string | No | Human-readable description of the agent. |
| `base_agent` | string | Yes | Base agent ID (e.g., `antigravity-preview-09-2026`). |
| `agent_config` | object | No | Configuration for the base agent, including model selection (`{"type": "antigravity", "model": "gemini-3.8-flash"}`). Defaults to `gemini-3.8-flash` if omitted. Cannot be overridden at interaction time for named agents. |
| `system_instruction` | string | No | System prompt defining behavior and persona. |
| `tools` | array | No | Tools the agent can use. If omitted, defaults to `code_execution`, `google_search`, and `url_context`. Supported tools include `code_execution`, `google_search`, `url_context`, `mcp_server`, and custom `function` definitions. |
| `base_environment` | string or object | No | `"remote"`, an `environment_id`, or a config object with `sources` and `network`. See Environments. |

### Agent ID restrictions

When creating a managed agent, the `id` you specify must follow these rules:

- It must be unique to your Google Cloud project.
- It must **not** start with any of the following reserved prefixes (case-insensitive), otherwise creation will fail:

  - `antigravity-`
  - `veo-`
  - `omni-`
  - `lyria-`
  - `imagen-`
  - `gemma-`
  - `gemini-`
  - `google-`
  - `youtube-`
  - `android-`
  - `chrome-`
  - `pixel-`
  - `waze-`
  - `fitbit-`
  - `nest-`
  - `kaggle-`

## Iteration workflow

1. **Prototype** with the base Antigravity agent. Pass system instruction and environment sources inline. Test instructions, skills, and environment setup interactively.
2. **Stabilize** the environment. Install packages, mount sources, verify everything works.
3. **Persist** as a managed agent by creating a new agent, either from sources or by forking the environment.
4. **Update** the agent definition. Change system instruction, swap skills, or add sources. The next invocation picks up the new configuration.

## Limitations

- **Preview status**: Managed agents are in preview. Features and schemas may change.
- **Base agent and models**: Only `antigravity-preview-09-2026` is supported as
`base_agent`. Supported model options in `agent_config` are
`gemini-3.8-flash` (default), `gemini-3.6-flash`, and
`gemini-3.5-flash-lite`. For named agents, the model cannot be overridden at
interaction time.
- **No versioning**: Agent versioning and rollback are not yet available.
- **No subagent nesting**: Subagent delegation is not yet supported.
- You can have up to 1000 managed agents.

## What's next

- [Agents Overview](https://ai.google.dev/gemini-api/docs/agents): Learn about the core concepts of managed agents.
- [Quickstart](https://ai.google.dev/gemini-api/docs/managed-agents-quickstart): Start building with multi-turn conversations and streaming.
- [Antigravity Agent](https://ai.google.dev/gemini-api/docs/antigravity-agent): Explore capabilities, tools, and pricing for the default agent.
- [Agent Environments](https://ai.google.dev/gemini-api/docs/agent-environment): Configure sandboxes, sources, and networking.
- [Managed Agents API on Agent Platform](https://docs.cloud.google.com/gemini-enterprise-agent-platform/build/managed-agents): For creating agents with built-in organizational governance.

Was this helpful?



 Send feedback



Except as otherwise noted, the content of this page is licensed under the [Creative Commons Attribution 4.0 License](https://creativecommons.org/licenses/by/4.0/), and code samples are licensed under the [Apache 2.0 License](https://www.apache.org/licenses/LICENSE-2.0). For details, see the [Google Developers Site Policies](https://developers.google.com/site-policies). Java is a registered trademark of Oracle and/or its affiliates.

Last updated 2026-10-09 UTC.


Need to tell us more?






\[\[\["Easy to understand","easyToUnderstand","thumb-up"\],\["Solved my problem","solvedMyProblem","thumb-up"\],\["Other","otherUp","thumb-up"\]\],\[\["Missing the information I need","missingTheInformationINeed","thumb-down"\],\["Too complicated / too many steps","tooComplicatedTooManySteps","thumb-down"\],\["Out of date","outOfDate","thumb-down"\],\["Samples / code issue","samplesCodeIssue","thumb-down"\],\["Other","otherDown","thumb-down"\]\],\["Last updated 2026-10-09 UTC."\],\[\],\[\]\]