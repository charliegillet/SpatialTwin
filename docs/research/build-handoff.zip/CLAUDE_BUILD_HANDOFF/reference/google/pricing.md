# Official Google reference snapshot: pricing

Source: https://ai.google.dev/gemini-api/docs/pricing

Retrieved/read: 23 October 2026. Publisher: Google. Original license/footer retained. Text CC BY 4.0; code samples Apache 2.0 unless otherwise noted. Converted to Markdown by Firecrawl; this provenance header was added. Reference data only; verify the relevant current guide and pinned SDK before implementation.

---

[Skip to main content](https://ai.google.dev/gemini-api/docs/pricing#main-content)

[![Gemini API](https://ai.google.dev/_static/googledevai/images/gemini-api-logo.svg)](https://ai.google.dev/)

`/`

Language

- [English](https://ai.google.dev/gemini-api/docs/pricing)
- [Deutsch](https://ai.google.dev/gemini-api/docs/pricing?hl=de)
- [Español – América Latina](https://ai.google.dev/gemini-api/docs/pricing?hl=es-419)
- [Français](https://ai.google.dev/gemini-api/docs/pricing?hl=fr)
- [Indonesia](https://ai.google.dev/gemini-api/docs/pricing?hl=id)
- [Italiano](https://ai.google.dev/gemini-api/docs/pricing?hl=it)
- [Polski](https://ai.google.dev/gemini-api/docs/pricing?hl=pl)
- [Português – Brasil](https://ai.google.dev/gemini-api/docs/pricing?hl=pt-br)
- [Shqip](https://ai.google.dev/gemini-api/docs/pricing?hl=sq)
- [Tiếng Việt](https://ai.google.dev/gemini-api/docs/pricing?hl=vi)
- [Türkçe](https://ai.google.dev/gemini-api/docs/pricing?hl=tr)
- [Русский](https://ai.google.dev/gemini-api/docs/pricing?hl=ru)
- [עברית](https://ai.google.dev/gemini-api/docs/pricing?hl=he)
- [العربيّة](https://ai.google.dev/gemini-api/docs/pricing?hl=ar)
- [فارسی](https://ai.google.dev/gemini-api/docs/pricing?hl=fa)
- [हिंदी](https://ai.google.dev/gemini-api/docs/pricing?hl=hi)
- [বাংলা](https://ai.google.dev/gemini-api/docs/pricing?hl=bn)
- [ภาษาไทย](https://ai.google.dev/gemini-api/docs/pricing?hl=th)
- [中文 – 简体](https://ai.google.dev/gemini-api/docs/pricing?hl=zh-cn)
- [中文 – 繁體](https://ai.google.dev/gemini-api/docs/pricing?hl=zh-tw)
- [日本語](https://ai.google.dev/gemini-api/docs/pricing?hl=ja)
- [한국어](https://ai.google.dev/gemini-api/docs/pricing?hl=ko)

[Get API key](https://aistudio.google.com/apikey) [Cookbook](https://github.com/google-gemini/cookbook) [Community](https://discuss.ai.google.dev/c/gemini-api/)

[Sign in](https://ai.google.dev/_d/signin?continue=https%3A%2F%2Fai.google.dev%2Fgemini-api%2Fdocs%2Fpricing&prompt=select_account)

- On this page
- [Gemini 4 Argon](https://ai.google.dev/gemini-api/docs/pricing#gemini-4-argon)
- [Gemini 3.8 Flash](https://ai.google.dev/gemini-api/docs/pricing#gemini-3.8-flash)
- [Gemini 3.6 Flash](https://ai.google.dev/gemini-api/docs/pricing#gemini-3.6-flash)
- [Gemini 3.8 Live, Gemini 3.8 Live Extended Thinking, and Gemini 3.1 Flash Live Preview](https://ai.google.dev/gemini-api/docs/pricing#gemini-3.8-live)
- [Gemini 3.5 Live Translate](https://ai.google.dev/gemini-api/docs/pricing#gemini-3.5-live-translate-preview)
- [Gemini 3.5 Transcribe Live](https://ai.google.dev/gemini-api/docs/pricing#gemini-3.5-transcribe-live)
- [Gemini 3.5 Transcribe](https://ai.google.dev/gemini-api/docs/pricing#gemini-3.5-transcribe)
- [Gemini 3.5 Flash-Lite](https://ai.google.dev/gemini-api/docs/pricing#gemini-3.5-flash-lite)
- [Gemini 3.1 Flash-Lite](https://ai.google.dev/gemini-api/docs/pricing#gemini-3.1-flash-lite)
- [Gemini Omni Flash](https://ai.google.dev/gemini-api/docs/pricing#gemini-omni-1.1-flash)
- [Gemini 3.1 Pro Preview](https://ai.google.dev/gemini-api/docs/pricing#gemini-3.1-pro-preview)
- [Gemini Nano Banana 2.1 🍌](https://ai.google.dev/gemini-api/docs/pricing#gemini-nano-banana-2.1)
- [Gemini 3.1 Flash Image (Nano Banana 2) 🍌](https://ai.google.dev/gemini-api/docs/pricing#gemini-3.1-flash-image)
- [Gemini 3.1 Flash Lite Image (Nano Banana 2 Lite) 🍌](https://ai.google.dev/gemini-api/docs/pricing#gemini-3.1-flash-lite-image)
- [Gemini 3.8 Flash TTS](https://ai.google.dev/gemini-api/docs/pricing#gemini-3.8-flash-tts)
- [Gemini 3.8 Flash-Lite TTS](https://ai.google.dev/gemini-api/docs/pricing#gemini-3.8-flash-lite-tts)
- [Gemini 3.1 Flash TTS Preview](https://ai.google.dev/gemini-api/docs/pricing#gemini-3.1-flash-tts-preview)
- [Gemini 3 Flash Preview](https://ai.google.dev/gemini-api/docs/pricing#gemini-3-flash-preview)
- [Gemini 3 Pro Image (Nano Banana Pro) 🍌](https://ai.google.dev/gemini-api/docs/pricing#gemini-3-pro-image)
- [Gemini 2.5 Pro](https://ai.google.dev/gemini-api/docs/pricing#gemini-2.5-pro)
- [Gemini 2.5 Flash](https://ai.google.dev/gemini-api/docs/pricing#gemini-2.5-flash)
- [Gemini 2.5 Flash-Lite](https://ai.google.dev/gemini-api/docs/pricing#gemini-2.5-flash-lite)
- [Gemini 2.5 Flash Native Audio (Live API)](https://ai.google.dev/gemini-api/docs/pricing#gemini-2.5-flash-native-audio)
- [Gemini 2.5 Flash Image (Nano Banana) 🍌](https://ai.google.dev/gemini-api/docs/pricing#gemini-2.5-flash-image)
- [Gemini 2.5 Flash Preview TTS](https://ai.google.dev/gemini-api/docs/pricing#gemini-2.5-flash-preview-tts)
- [Gemini 2.5 Pro Preview TTS](https://ai.google.dev/gemini-api/docs/pricing#gemini-2.5-pro-preview-tts)
- [Lyria 3.5](https://ai.google.dev/gemini-api/docs/pricing#lyria-3-5)
- [Lyria 3](https://ai.google.dev/gemini-api/docs/pricing#lyria-3)
- [Gemini Embedding 2](https://ai.google.dev/gemini-api/docs/pricing#gemini-embedding-2)
- [Gemini Robotics ER 2 Preview](https://ai.google.dev/gemini-api/docs/pricing#gemini-robotics-er-2)
- [Gemini Robotics ER 2 Streaming Preview](https://ai.google.dev/gemini-api/docs/pricing#gemini-robotics-er-2-streaming)
- [Gemma 4](https://ai.google.dev/gemini-api/docs/pricing#gemma-4)
- [Pricing for tools](https://ai.google.dev/gemini-api/docs/pricing#pricing-for-tools)
- [Pricing for agents](https://ai.google.dev/gemini-api/docs/pricing#pricing-for-agents)
- [Notes](https://ai.google.dev/gemini-api/docs/pricing#notes)

Gemini 4 Argon is now available. [Try it out](https://aistudio.google.com/prompts/new_chat?model=gemini-4-argon).


- [Home](https://ai.google.dev/)
- [Gemini API](https://ai.google.dev/gemini-api)
- [Docs](https://ai.google.dev/gemini-api/docs)

# Gemini Developer API pricing

- On this page
- [Gemini 4 Argon](https://ai.google.dev/gemini-api/docs/pricing#gemini-4-argon)
- [Gemini 3.8 Flash](https://ai.google.dev/gemini-api/docs/pricing#gemini-3.8-flash)
- [Gemini 3.6 Flash](https://ai.google.dev/gemini-api/docs/pricing#gemini-3.6-flash)
- [Gemini 3.8 Live, Gemini 3.8 Live Extended Thinking, and Gemini 3.1 Flash Live Preview](https://ai.google.dev/gemini-api/docs/pricing#gemini-3.8-live)
- [Gemini 3.5 Live Translate](https://ai.google.dev/gemini-api/docs/pricing#gemini-3.5-live-translate-preview)
- [Gemini 3.5 Transcribe Live](https://ai.google.dev/gemini-api/docs/pricing#gemini-3.5-transcribe-live)
- [Gemini 3.5 Transcribe](https://ai.google.dev/gemini-api/docs/pricing#gemini-3.5-transcribe)
- [Gemini 3.5 Flash-Lite](https://ai.google.dev/gemini-api/docs/pricing#gemini-3.5-flash-lite)
- [Gemini 3.1 Flash-Lite](https://ai.google.dev/gemini-api/docs/pricing#gemini-3.1-flash-lite)
- [Gemini Omni Flash](https://ai.google.dev/gemini-api/docs/pricing#gemini-omni-1.1-flash)
- [Gemini 3.1 Pro Preview](https://ai.google.dev/gemini-api/docs/pricing#gemini-3.1-pro-preview)
- [Gemini Nano Banana 2.1 🍌](https://ai.google.dev/gemini-api/docs/pricing#gemini-nano-banana-2.1)
- [Gemini 3.1 Flash Image (Nano Banana 2) 🍌](https://ai.google.dev/gemini-api/docs/pricing#gemini-3.1-flash-image)
- [Gemini 3.1 Flash Lite Image (Nano Banana 2 Lite) 🍌](https://ai.google.dev/gemini-api/docs/pricing#gemini-3.1-flash-lite-image)
- [Gemini 3.8 Flash TTS](https://ai.google.dev/gemini-api/docs/pricing#gemini-3.8-flash-tts)
- [Gemini 3.8 Flash-Lite TTS](https://ai.google.dev/gemini-api/docs/pricing#gemini-3.8-flash-lite-tts)
- [Gemini 3.1 Flash TTS Preview](https://ai.google.dev/gemini-api/docs/pricing#gemini-3.1-flash-tts-preview)
- [Gemini 3 Flash Preview](https://ai.google.dev/gemini-api/docs/pricing#gemini-3-flash-preview)
- [Gemini 3 Pro Image (Nano Banana Pro) 🍌](https://ai.google.dev/gemini-api/docs/pricing#gemini-3-pro-image)
- [Gemini 2.5 Pro](https://ai.google.dev/gemini-api/docs/pricing#gemini-2.5-pro)
- [Gemini 2.5 Flash](https://ai.google.dev/gemini-api/docs/pricing#gemini-2.5-flash)
- [Gemini 2.5 Flash-Lite](https://ai.google.dev/gemini-api/docs/pricing#gemini-2.5-flash-lite)
- [Gemini 2.5 Flash Native Audio (Live API)](https://ai.google.dev/gemini-api/docs/pricing#gemini-2.5-flash-native-audio)
- [Gemini 2.5 Flash Image (Nano Banana) 🍌](https://ai.google.dev/gemini-api/docs/pricing#gemini-2.5-flash-image)
- [Gemini 2.5 Flash Preview TTS](https://ai.google.dev/gemini-api/docs/pricing#gemini-2.5-flash-preview-tts)
- [Gemini 2.5 Pro Preview TTS](https://ai.google.dev/gemini-api/docs/pricing#gemini-2.5-pro-preview-tts)
- [Lyria 3.5](https://ai.google.dev/gemini-api/docs/pricing#lyria-3-5)
- [Lyria 3](https://ai.google.dev/gemini-api/docs/pricing#lyria-3)
- [Gemini Embedding 2](https://ai.google.dev/gemini-api/docs/pricing#gemini-embedding-2)
- [Gemini Robotics ER 2 Preview](https://ai.google.dev/gemini-api/docs/pricing#gemini-robotics-er-2)
- [Gemini Robotics ER 2 Streaming Preview](https://ai.google.dev/gemini-api/docs/pricing#gemini-robotics-er-2-streaming)
- [Gemma 4](https://ai.google.dev/gemini-api/docs/pricing#gemma-4)
- [Pricing for tools](https://ai.google.dev/gemini-api/docs/pricing#pricing-for-tools)
- [Pricing for agents](https://ai.google.dev/gemini-api/docs/pricing#pricing-for-agents)
- [Notes](https://ai.google.dev/gemini-api/docs/pricing#notes)

Start building free of charge with generous limits, then scale up with
prepaid and pay-as-you-go pricing for your production-ready applications.

### Free

For developers and small projects getting started with the Gemini API.

- check\_circleLimited access to certain models
- check\_circleFree input & output tokens
- check\_circleGoogle AI Studio access
- check\_circleContent used to improve our products [\*](https://ai.google.dev/gemini-api/terms)

[Get started for Free](https://aistudio.google.com/)

### Paid

For production applications that require higher volumes and advanced features.

- check\_circleHigher rate limits for production deployments
- check\_circleAccess to Context caching
- check\_circleBatch API (50% cost reduction)
- check\_circleAccess to Google's most advanced models
- check\_circleContent **not** used to improve our products [\*](https://ai.google.dev/gemini-api/terms)

[Upgrade to Paid](https://aistudio.google.com/api-keys)

### Enterprise

For enterprise deployments, powered by [Gemini Enterprise Agent Platform](https://cloud.google.com/gemini-enterprise-agent-platform).

- check\_circleAll features in Paid, plus optional access to:
- check\_circleDedicated support channels
- check\_circleAdvanced security & compliance
- check\_circleProvisioned throughput
- check\_circleVolume-based discounts (based on usage)
- check\_circleML ops, model garden and more

[Contact Sales](https://cloud.google.com/contact)

## Gemini 4 Argon

_[`gemini-4-argon`](https://ai.google.dev/gemini-api/docs/models/gemini-4-argon)_

[Try it in Google AI Studio](https://aistudio.google.com/prompts/new_chat?model=gemini-4-argon)

Our flagship reasoning model, built for complex software engineering, deep mathematical and scientific problem solving, autonomous multi-step agents, and long-decode generation up to 1M tokens.

[Standard](https://ai.google.dev/gemini-api/docs/pricing#standard)[Batch](https://ai.google.dev/gemini-api/docs/pricing#batch)[Flex](https://ai.google.dev/gemini-api/docs/pricing#flex)[Priority](https://ai.google.dev/gemini-api/docs/pricing#priority)[Contributor](https://ai.google.dev/gemini-api/docs/pricing#contributor)More

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $2.00 through November 30, 2026.<br>$4.00 starting December 1, 2026. |
| Output price (including thinking tokens) | Not available | $10.00 through November 30, 2026.<br>$20.00 starting December 1, 2026. |
| Context caching price | Not available | $0.10 through November 30, 2026.<br>$0.20 starting December 1, 2026.<br>Implicit caching only (explicit caching is not supported). |
| Grounding with Google Search\* | Not available | 5,000 free search requests per month (shared across all Gemini 3 and newer models), then $14 per 1,000 requests. |
| Grounding with Google Maps | Not available | 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000 search queries. |
| Used to improve our products | Not available | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $1.00 through November 30, 2026.<br>$2.00 starting December 1, 2026. |
| Output price (including thinking tokens) | Not available | $5.00 through November 30, 2026.<br>$10.00 starting December 1, 2026. |
| Context caching price | Not available | $0.05 through November 30, 2026.<br>$0.10 starting December 1, 2026.<br>Implicit caching only (explicit caching is not supported). |
| Used to improve our products | Not available | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $1.00 through November 30, 2026.<br>$2.00 starting December 1, 2026. |
| Output price (including thinking tokens) | Not available | $5.00 through November 30, 2026.<br>$10.00 starting December 1, 2026. |
| Context caching price | Not available | $0.05 through November 30, 2026.<br>$0.10 starting December 1, 2026.<br>Implicit caching only (explicit caching is not supported). |
| Used to improve our products | Not available | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $3.60 through November 30, 2026.<br>$7.20 starting December 1, 2026. |
| Output price (including thinking tokens) | Not available | $18.00 through November 30, 2026.<br>$36.00 starting December 1, 2026. |
| Context caching price | Not available | $0.18 through November 30, 2026.<br>$0.36 starting December 1, 2026.<br>Implicit caching only (explicit caching is not supported). |
| Grounding with Google Search\* | Not available | 5,000 free search requests per month (shared across all Gemini 3 and newer models), then $14 per 1,000 requests. |
| Grounding with Google Maps | Not available | 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000 search queries. |
| Used to improve our products | Not available | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $1.00 through November 30, 2026.<br>$2.00 starting December 1, 2026. |
| Output price (including thinking tokens) | Not available | $5.00 through November 30, 2026.<br>$10.00 starting December 1, 2026. |
| Context caching price | Not available | $0.05 through November 30, 2026.<br>$0.10 starting December 1, 2026.<br>Implicit caching only (explicit caching is not supported). |
| Used to improve our products | Not available | [Yes](https://ai.google.dev/gemini-api/docs/logs-policy#contributor-tier) |

\* A customer-submitted request to Gemini may result in one or more
queries to Google Search. You will be charged for each individual search query
performed.

## Gemini 3.8 Flash

_[`gemini-3.8-flash`](https://ai.google.dev/gemini-api/docs/models/gemini-3.8-flash)_

[Try it in Google AI Studio](https://aistudio.google.com/prompts/new_chat?model=gemini-3.8-flash)

Our most intelligent Flash model, engineered for long-horizon software engineering, autonomous agents, and complex enterprise workflows.

[Standard](https://ai.google.dev/gemini-api/docs/pricing#standard)[Batch](https://ai.google.dev/gemini-api/docs/pricing#batch)[Flex](https://ai.google.dev/gemini-api/docs/pricing#flex)[Priority](https://ai.google.dev/gemini-api/docs/pricing#priority)[Contributor](https://ai.google.dev/gemini-api/docs/pricing#contributor)More

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Free of charge | $0.75 through December 31, 2026.<br>$1.50 starting January 1, 2027. |
| Output price (including thinking tokens) | Free of charge | $3.75 through December 31, 2026.<br>$7.50 starting January 1, 2027. |
| Context caching price | Free of charge | $0.075 through December 31, 2026.<br>$0.15 starting January 1, 2027.<br>$0.50 / 1,000,000 tokens per hour (storage price) through December 31, 2026.<br>$1.00 / 1,000,000 tokens per hour (storage price) starting January 1, 2027. |
| Grounding with Google Search\* | Not available | 5,000 free search requests per month (shared across all Gemini 3 and newer models), then $14 per 1,000 requests. |
| Grounding with Google Maps | Not available | 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000 search queries. |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $0.375 through December 31, 2026.<br>$0.75 starting January 1, 2027. |
| Output price (including thinking tokens) | Not available | $1.875 through December 31, 2026.<br>$3.75 starting January 1, 2027. |
| Context caching price | Not available | $0.0375 through December 31, 2026.<br>$0.075 starting January 1, 2027.<br>$0.50 / 1,000,000 tokens per hour (storage price) through December 31, 2026.<br>$1.00 / 1,000,000 tokens per hour (storage price) starting January 1, 2027. |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $0.375 through December 31, 2026.<br>$0.75 starting January 1, 2027. |
| Output price (including thinking tokens) | Not available | $1.875 through December 31, 2026.<br>$3.75 starting January 1, 2027. |
| Context caching price | Not available | $0.0375 through December 31, 2026.<br>$0.075 starting January 1, 2027.<br>$0.50 / 1,000,000 tokens per hour (storage price) through December 31, 2026.<br>$1.00 / 1,000,000 tokens per hour (storage price) starting January 1, 2027. |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Free of charge | $1.35 through December 31, 2026.<br>$2.70 starting January 1, 2027. |
| Output price (including thinking tokens) | Free of charge | $6.75 through December 31, 2026.<br>$13.50 starting January 1, 2027. |
| Context caching price | Free of charge | $0.135 through December 31, 2026.<br>$0.27 starting January 1, 2027.<br>$0.50 / 1,000,000 tokens per hour (storage price) through December 31, 2026.<br>$1.00 / 1,000,000 tokens per hour (storage price) starting January 1, 2027. |
| Grounding with Google Search\* | Not available\*\* | 5,000 free search requests per month (shared across all Gemini 3 and newer models), then $14 per 1,000 requests. |
| Grounding with Google Maps | Not available\*\* | 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000 search queries. |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Free of charge | $0.375 through December 31, 2026.<br>$0.75 starting January 1, 2027. |
| Output price (including thinking tokens) | Free of charge | $1.875 through December 31, 2026.<br>$3.75 starting January 1, 2027. |
| Context caching price | Free of charge | $0.0375 through December 31, 2026.<br>$0.075 starting January 1, 2027.<br>$0.50 / 1,000,000 tokens per hour (storage price) through December 31, 2026.<br>$1.00 / 1,000,000 tokens per hour (storage price) starting January 1, 2027. |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [Yes](https://ai.google.dev/gemini-api/docs/logs-policy#contributor-tier) |

## Gemini 3.6 Flash

_[`gemini-3.6-flash`](https://ai.google.dev/gemini-api/docs/models/gemini-3.6-flash)_

[Try it in Google AI Studio](https://aistudio.google.com/prompts/new_chat?model=gemini-3.6-flash)

Our previous generation Flash model, balancing speed and multimodal capabilities across general agentic and everyday tasks.

[Standard](https://ai.google.dev/gemini-api/docs/pricing#standard)[Batch](https://ai.google.dev/gemini-api/docs/pricing#batch)[Flex](https://ai.google.dev/gemini-api/docs/pricing#flex)[Priority](https://ai.google.dev/gemini-api/docs/pricing#priority)More

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Free of charge | $0.75 through December 31, 2026.<br>$1.50 starting January 1, 2027. |
| Output price (including thinking tokens) | Free of charge | $3.75 through December 31, 2026.<br>$7.50 starting January 1, 2027. |
| Context caching price | Free of charge | $0.075 through December 31, 2026.<br>$0.15 starting January 1, 2027.<br>$0.50 / 1,000,000 tokens per hour (storage price) through December 31, 2026.<br>$1.00 / 1,000,000 tokens per hour (storage price) starting January 1, 2027. |
| Grounding with Google Search\* | Not available\*\* | 5,000 free search requests per month (shared across all Gemini 3 and newer models), then $14 per 1,000 requests. |
| Grounding with Google Maps | Not available\*\* | 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000 search queries. |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $0.375 through December 31, 2026.<br>$0.75 starting January 1, 2027. |
| Output price (including thinking tokens) | Not available | $1.875 through December 31, 2026.<br>$3.75 starting January 1, 2027. |
| Context caching price | Not available | $0.0375 through December 31, 2026.<br>$0.075 starting January 1, 2027.<br>$0.50 / 1,000,000 tokens per hour (storage price) through December 31, 2026.<br>$1.00 / 1,000,000 tokens per hour (storage price) starting January 1, 2027. |
| Grounding with Google Search\* | Not available\*\* | 5,000 free search requests per month (shared across all Gemini 3 and newer models), then $14 per 1,000 requests. |
| Grounding with Google Maps | Not available\*\* | 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000 search queries. |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $0.375 through December 31, 2026.<br>$0.75 starting January 1, 2027. |
| Output price (including thinking tokens) | Not available | $1.875 through December 31, 2026.<br>$3.75 starting January 1, 2027. |
| Context caching price | Not available | $0.0375 through December 31, 2026.<br>$0.075 starting January 1, 2027.<br>$0.50 / 1,000,000 tokens per hour (storage price) through December 31, 2026.<br>$1.00 / 1,000,000 tokens per hour (storage price) starting January 1, 2027. |
| Grounding with Google Search\* | Not available\*\* | 5,000 free search requests per month (shared across all Gemini 3 and newer models), then $14 per 1,000 requests. |
| Grounding with Google Maps | Not available\*\* | 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000 search queries. |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Free of charge | $1.35 through December 31, 2026.<br>$2.70 starting January 1, 2027. |
| Output price (including thinking tokens) | Free of charge | $6.75 through December 31, 2026.<br>$13.50 starting January 1, 2027. |
| Context caching price | Free of charge | $0.135 through December 31, 2026.<br>$0.27 starting January 1, 2027.<br>$0.50 / 1,000,000 tokens per hour (storage price) through December 31, 2026.<br>$1.00 / 1,000,000 tokens per hour (storage price) starting January 1, 2027. |
| Grounding with Google Search\* | Not available\*\* | 5,000 free search requests per month (shared across all Gemini 3 and newer models), then $14 per 1,000 requests. |
| Grounding with Google Maps | Not available\*\* | 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000 search queries. |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

\* A customer-submitted request to Gemini may result in one or more
queries to Google Search. You will be charged for each individual search query
performed.

\*\* Can be tested in Google AI Studio.

## Gemini 3.8 Live, Gemini 3.8 Live Extended Thinking, and Gemini 3.1 Flash Live Preview

_[`gemini-3.8-live`](https://ai.google.dev/gemini-api/docs/models/gemini-3.8-live), [`gemini-3.8-live-extended-thinking`](https://ai.google.dev/gemini-api/docs/models/gemini-3.8-live-extended-thinking), and [`gemini-3.1-flash-live-preview`](https://ai.google.dev/gemini-api/docs/models/gemini-3.1-flash-live-preview)_

[Try it in Google AI Studio](https://aistudio.google.com/live?model=gemini-3.8-live)

Our low-latency, audio-to-audio models optimized for real-time voice agents and
live dialogue, including background reasoning support with Extended Thinking.

[Standard](https://ai.google.dev/gemini-api/docs/pricing#standard)More

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Free of charge | $0.75 (text)<br>$3.00 or $0.005/min (audio)<br>$1.00 or $0.002/min (image/video) |
| Output price (including thinking tokens) | Free of charge | $4.50 (text)<br>$12.00 or $0.018/min (audio) |
| Grounding with Google Search\* | Supported | 5,000 free search requests per month (shared across all Gemini 3 and newer models), then $14 per 1,000 requests. |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

\* A customer-submitted request to Gemini may result in one or more
queries to Google Search. You will be charged for each individual search query
performed.

## Gemini 3.5 Live Translate

_[`gemini-3.5-live-translate-preview`](https://ai.google.dev/gemini-api/docs/models/gemini-3.5-live-translate-preview)_

[Try it in Google AI Studio](https://aistudio.google.com/live?model=gemini-3.5-live-translate-preview)

Our low-latency, real-time speech to speech translation model that supports 70+ languages.

[Standard](https://ai.google.dev/gemini-api/docs/pricing#standard)More

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Free of charge | $3.50 or $0.0053/min\* (audio) |
| Output price (including thinking tokens) | Free of charge | $21.00 or $0.0315/min\* (audio) |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

\* Billing is based on total input and output audio token consumption, calculated at a rate of 25 tokens per second of audio, equating to an effective price of approximately $0.0368 per minute.

## Gemini 3.5 Transcribe Live

_[`gemini-3.5-transcribe-live`](https://ai.google.dev/gemini-api/docs/models/gemini-3.5-transcribe)_

[Try it in Google AI Studio](https://aistudio.google.com/?model=gemini-3.5-transcribe-live)

Our low-latency, real-time speech-to-text model for bidirectional streaming audio transcription over WebSockets.

[Standard](https://ai.google.dev/gemini-api/docs/pricing#standard)More

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Free of charge | $3.50 or $0.005/min\* (audio) |
| Output price (including thinking tokens) | Free of charge | $21.00 or $0.004/min\* (text) |
| Grounding with Google Search | Not Supported |  |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

\* Estimated pricing is based on 25 audio tokens per second for input
and 175 text tokens per minute for output, for an effective blended rate of
~$0.009 per min for Live Transcribe.

## Gemini 3.5 Transcribe

_[`gemini-3.5-transcribe`](https://ai.google.dev/gemini-api/docs/models/gemini-3.5-transcribe)_

[Try it in Google AI Studio](https://aistudio.google.com/?model=gemini-3.5-transcribe)

Our speech-to-text model with automatic language detection, speaker diarization, word-level timestamps, and custom vocabulary biasing.

[Standard](https://ai.google.dev/gemini-api/docs/pricing#standard)More

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Free of charge | $2.00 or $0.003/min\* (audio) |
| Output price (including thinking tokens) | Free of charge | $12.00 or $0.002/min\* (text) |
| Grounding with Google Search | Not Supported |  |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

\* Estimated pricing is based on 25 audio tokens per second for input
and 175 text tokens per minute for output, for an effective blended rate of
~$0.005 per min for Transcribe.

## Gemini 3.5 Flash-Lite

_[`gemini-3.5-flash-lite`](https://ai.google.dev/gemini-api/docs/models/gemini-3.5-flash-lite)_

[Try it in Google AI Studio](https://aistudio.google.com/prompts/new_chat?model=gemini-3.5-flash-lite)

A cost-efficient model, optimized for high-volume agentic tasks,
translation, and simple data processing.

[Standard](https://ai.google.dev/gemini-api/docs/pricing#standard)[Batch](https://ai.google.dev/gemini-api/docs/pricing#batch)[Flex](https://ai.google.dev/gemini-api/docs/pricing#flex)[Priority](https://ai.google.dev/gemini-api/docs/pricing#priority)[Contributor](https://ai.google.dev/gemini-api/docs/pricing#contributor)More

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Free of charge | $0.30 (text / image / video / audio) |
| Output price (including thinking tokens) | Free of charge | $2.50 |
| Context caching price | Not available | $0.03<br>$1.00 / 1,000,000 tokens per hour (storage price) |
| Grounding with Google Search\* | Not available\*\* | 5,000 free search requests per month (shared across all Gemini 3 and newer models), then $14 per 1,000 requests. |
| Grounding with Google Maps | Not available\*\* | 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000 search queries. |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Free of charge | $0.15 (text / image / video / audio) |
| Output price (including thinking tokens) | Free of charge | $1.25 |
| Context caching price | Not available | $0.02<br>$1.00 / 1,000,000 tokens per hour (storage price) |
| Grounding with Google Search\* | Not available\*\* | 5,000 free search requests per month (shared across all Gemini 3 and newer models), then $14 per 1,000 requests. |
| Grounding with Google Maps | Not available\*\* | 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000 search queries. |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Free of charge | $0.15 (text / image / video / audio) |
| Output price (including thinking tokens) | Free of charge | $1.25 |
| Context caching price | Not available | $0.02<br>$1.00 / 1,000,000 tokens per hour (storage price) |
| Grounding with Google Search\* | Not available\*\* | 5,000 free search requests per month (shared across all Gemini 3 and newer models), then $14 per 1,000 requests. |
| Grounding with Google Maps | Not available\*\* | 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000 search queries. |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Free of charge | $0.54 (text / image / video / audio) |
| Output price (including thinking tokens) | Free of charge | $4.50 |
| Context caching price | Not available | $0.05<br>$1.00 / 1,000,000 tokens per hour (storage price) |
| Grounding with Google Search\* | Not available\*\* | 5,000 free search requests per month (shared across all Gemini 3 and newer models), then $14 per 1,000 requests. |
| Grounding with Google Maps | Not available\*\* | 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000 search queries. |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Free of charge | $0.15 (text / image / video / audio) |
| Output price (including thinking tokens) | Free of charge | $1.25 |
| Context caching price | Not available | $0.015<br>$1.00 / 1,000,000 tokens per hour (storage price) |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [Yes](https://ai.google.dev/gemini-api/docs/logs-policy#contributor-tier) |

\* A customer-submitted request to Gemini may result in one or more
queries to Google Search. You will be charged for each individual search query
performed.

\*\* Can be tested in Google AI Studio.

\*\* Can be tested in Google AI Studio.

## Gemini 3.1 Flash-Lite

_[`gemini-3.1-flash-lite`](https://ai.google.dev/gemini-api/docs/models/gemini-3.1-flash-lite)_

[Try it in Google AI Studio](https://aistudio.google.com/prompts/new_chat?model=gemini-3.1-flash-lite)

A cost-efficient model, optimized for high-volume agentic tasks,
translation, and simple data processing.

[Standard](https://ai.google.dev/gemini-api/docs/pricing#standard)[Batch](https://ai.google.dev/gemini-api/docs/pricing#batch)[Flex](https://ai.google.dev/gemini-api/docs/pricing#flex)[Priority](https://ai.google.dev/gemini-api/docs/pricing#priority)More

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Free of charge | $0.25 (text / image / video)<br>$0.50 (audio) |
| Output price (including thinking tokens) | Free of charge | $1.50 |
| Context caching price | Not available | $0.025 (text / image / video)<br>$0.05 (audio)<br>$1.00 / 1,000,000 tokens per hour (storage price) |
| Grounding with Google Search\* | Not available\*\* | 5,000 free search requests per month (shared across all Gemini 3 and newer models), then $14 per 1,000 requests. |
| Grounding with Google Maps | Not available\*\* | 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000 search queries. |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Free of charge | $0.125 (text / image / video)<br>$0.25 (audio) |
| Output price (including thinking tokens) | Free of charge | $0.75 |
| Context caching price | Not available | $0.0125 (text / image / video)<br>$0.025 (audio)<br>$0.50 / 1,000,000 tokens per hour (storage price) |
| Grounding with Google Search\* | Not available\*\* | 5,000 free search requests per month (shared across all Gemini 3 and newer models), then $14 per 1,000 requests. |
| Grounding with Google Maps | Not available\*\* | 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000 search queries. |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Free of charge | $0.125 (text / image / video)<br>$0.25 (audio) |
| Output price (including thinking tokens) | Free of charge | $0.75 |
| Context caching price | Not available | $0.0125 (text / image / video)<br>$0.025 (audio)<br>$0.50 / 1,000,000 tokens per hour (storage price) |
| Grounding with Google Search\* | Not available\*\* | 5,000 free search requests per month (shared across all Gemini 3 and newer models), then $14 per 1,000 requests. |
| Grounding with Google Maps | Not available\*\* | 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000 search queries. |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Free of charge | $0.45 (text / image / video)<br>$0.90 (audio) |
| Output price (including thinking tokens) | Free of charge | $2.70 |
| Context caching price | Not available | $0.045 (text / image / video)<br>$0.09 (audio)<br>$1.80 / 1,000,000 tokens per hour (storage price) |
| Grounding with Google Search\* | Not available\*\* | 5,000 free search requests per month (shared across all Gemini 3 and newer models), then $14 per 1,000 requests. |
| Grounding with Google Maps | Not available\*\* | 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000 search queries. |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

\* A customer-submitted request to Gemini may result in one or more
queries to Google Search. You will be charged for each individual search query
performed.

\*\* Can be tested in Google AI Studio.

## Gemini Omni Flash

_[`gemini-omni-1.1-flash`](https://ai.google.dev/gemini-api/docs/models/gemini-omni-flash)_

[Try it in Google AI Studio](https://aistudio.google.com/prompts/new_chat?model=gemini-omni-1.1-flash)

Our next-generation video generation and editing model, now generally available
to developers on the paid tier of the Gemini API.

[Standard](https://ai.google.dev/gemini-api/docs/pricing#standard)More

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $1.50 (text / image / video / audio) |
| Output price (including thinking tokens) | Not available | $9.00 (text)<br>$17.50 (video)\* |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

\* Billing is based on total output token consumption, calculated at
a rate of 5,792 tokens per second of 720p video. Under Standard pricing, this
equates to an effective price of approximately $0.10 per second.

## Gemini 3.1 Pro Preview

_[`gemini-3.1-pro-preview`](https://ai.google.dev/gemini-api/docs/models/gemini-3.1-pro-preview) and [`gemini-3.1-pro-preview-customtools`](https://ai.google.dev/gemini-api/docs/models/gemini-3.1-pro-preview#gemini-31-pro-preview-customtools)_

[Try it in Google AI Studio](https://aistudio.google.com/prompts/new_chat?model=gemini-3.1-pro-preview)

Our 3rd generation Pro model, built for multimodal understanding,
agentic capabilities, and vibe-coding.

[Standard](https://ai.google.dev/gemini-api/docs/pricing#standard)[Batch](https://ai.google.dev/gemini-api/docs/pricing#batch)[Flex](https://ai.google.dev/gemini-api/docs/pricing#flex)[Priority](https://ai.google.dev/gemini-api/docs/pricing#priority)[Contributor](https://ai.google.dev/gemini-api/docs/pricing#contributor)More

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $2.00, prompts <= 200k tokens<br>$4.00, prompts > 200k tokens |
| Output price (including thinking tokens) | Not available | $12.00, prompts <= 200k tokens<br>$18.00, prompts > 200k |
| Context caching price | Not available | $0.20, prompts <= 200k tokens<br>$0.40, prompts > 200k<br>$4.50 / 1,000,000 tokens per hour (storage price) |
| Grounding with Google Search\* | Not available\*\* | 5,000 free search requests per month (shared across all Gemini 3 and newer models), then $14 per 1,000 requests. |
| Grounding with Google Maps | Not available\*\* | 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000 search queries. |
| Used to improve our products | N/A | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $1.00, prompts <= 200k tokens<br>$2.00, prompts > 200k tokens |
| Output price (including thinking tokens) | Not available | $6.00, prompts <= 200k tokens<br>$9.00, prompts > 200k |
| Context caching price | Not available | _Same as Standard_<br> $0.20, prompts <= 200k tokens<br>$0.40, prompts > 200k<br>$4.50 / 1,000,000 tokens per hour (storage price) |
| Grounding with Google Search\* | Not available\*\* | 5,000 free search requests per month (shared across all Gemini 3 and newer models), then $14 per 1,000 requests. |
| Grounding with Google Maps | Not available\*\* | 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000 search queries. |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $1.00, prompts <= 200k tokens<br>$2.00, prompts > 200k tokens |
| Output price (including thinking tokens) | Not available | $6.00, prompts <= 200k tokens<br>$9.00, prompts > 200k |
| Context caching price | Not available | _Same as Standard_<br> $0.20, prompts <= 200k tokens<br>$0.40, prompts > 200k<br>$4.50 / 1,000,000 tokens per hour (storage price) |
| Grounding with Google Search\* | Not available\*\* | 5,000 free search requests per month (shared across all Gemini 3 and newer models), then $14 per 1,000 requests. |
| Grounding with Google Maps | Not available\*\* | 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000 search queries. |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $3.60, prompts <= 200k tokens<br>$7.20, prompts > 200k tokens |
| Output price (including thinking tokens) | Not available | $21.60, prompts <= 200k tokens<br>$32.40, prompts > 200k |
| Context caching price | Not available | $0.36, prompts <= 200k tokens<br>$0.72, prompts > 200k<br>$8.10 / 1,000,000 tokens per hour (storage price) |
| Grounding with Google Search\* | Not available\*\* | 5,000 free search requests per month (shared across all Gemini 3 and newer models), then $14 per 1,000 requests. |
| Grounding with Google Maps | Not available\*\* | 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000 search queries. |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $1.00, prompts <= 200k tokens<br>$2.00, prompts > 200k tokens |
| Output price (including thinking tokens) | Not available | $6.00, prompts <= 200k tokens<br>$9.00, prompts > 200k tokens |
| Context caching price | Not available | $0.10, prompts <= 200k tokens<br>$0.20, prompts > 200k tokens<br>$4.50 / 1,000,000 tokens per hour (storage price) |
| Used to improve our products | N/A | [Yes](https://ai.google.dev/gemini-api/docs/logs-policy#contributor-tier) |

\* A customer-submitted request to Gemini may result in one or more
queries to Google Search. You will be charged for each individual search query
performed.

\*\* Can be tested in Google AI Studio.

## Gemini Nano Banana 2.1 🍌

_[`gemini-nano-banana-2.1`](https://ai.google.dev/gemini-api/docs/models/gemini-nano-banana-2.1)_

[Try it in Google AI Studio](https://aistudio.google.com/prompts/new_chat?model=gemini-nano-banana-2.1)

An update to Nano Banana 2 (Gemini 3.1 Flash Image), built for high-efficiency
image generation and conversational editing with improved visual quality,
multi-turn character consistency, accurate text rendering, and search-grounded
generation across 1K, 2K, and 4K resolutions.

[Standard](https://ai.google.dev/gemini-api/docs/pricing#standard)[Batch](https://ai.google.dev/gemini-api/docs/pricing#batch)More

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $1.50 (text/image/video) |
| Output price | Not available | $7.50 (text and thinking)<br> $30.00 (images)<br> Equivalent to $0.0336 per 1K image\*,<br> $0.0504 per 2K image\*,<br> and $0.113 per 4K image\*. |
| Grounding with Google Web and Image Search\*\* | Not available | 5,000 free search requests per month (shared across all Gemini 3 and newer models), then $14 per 1,000 requests for text and image-based grounding. |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $0.75 (text/image/video) |
| Output price | Not available | $3.75 (text and thinking)<br> $15.00 (images)<br> Equivalent to $0.0168 per 1K image\*,<br> $0.0252 per 2K image\*,<br> and $0.0567 per 4K image\*. |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

\* Image output is priced at $30 per 1,000,000 tokens (Standard) and
$15 per 1,000,000 tokens (Batch). Output images at 1K (1024x1024px) consume 1120
tokens and are equivalent to $0.0336 per image. Output images at 2K
(2048x2048px) consume 1680 tokens and are equivalent to $0.0504 per image.
Output images at 4K (4096x4096px) consume 3780 tokens and are equivalent to
$0.113 per image.

\*\* A customer-submitted request to Gemini may result in one or more
queries to Google Search. You will be charged for each individual search query
performed. Retrieved context (text or images) provided by Grounding with Google
Search is not charged as input tokens.

## Gemini 3.1 Flash Image (Nano Banana 2) 🍌

_[`gemini-3.1-flash-image`](https://ai.google.dev/gemini-api/docs/models/gemini-3.1-flash-image)_

[Try it in Google AI Studio](https://aistudio.google.com/prompts/new_chat?model=gemini-3.1-flash-image)

Designed for speed and efficiency, the Gemini 3.1 Flash Image generation model is
effective for quick, interactive responses and high throughput.

[Standard](https://ai.google.dev/gemini-api/docs/pricing#standard)[Batch](https://ai.google.dev/gemini-api/docs/pricing#batch)More

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $0.50 (text/image) |
| Output price | Not available | $3 (text and thinking)<br> $60.00 (images)<br> Equivalent to $0.045 per 0.5K image\*<br> $0.067 per 1K image\*,<br> $0.101 per 2K image\*,<br> and $0.151 per 4K image\*. |
| Grounding with Google Web and Image Search\*\* | Not available\\*\\*\\* | 5,000 free search requests per month (shared across all Gemini 3 and newer models), then $14 per 1,000 requests for text and image-based grounding. |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $0.25 (text, image) |
| Output price | Not available | $1.50 (text and thinking)<br> $30.00 (images)<br> Equivalent to $0.022 per 0.5K image\*<br> $0.034 per 1K image\*,<br> $0.050 per 2K image\*,<br> and $0.076 per 4K image\*. |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

\* Image output is priced at $60 per 1,000,000 tokens.
Output images at 0.5K (512px) consume 747 tokens and are equivalent to $0.045 per
image. Output images at 1K (1024x1024px) consume 1120 tokens and are equivalent
to $0.067 per image. Output images at 2K (2048x2048px) consume 1680 tokens and
are equivalent to $0.101 per image. Output images at 4K (4096x4096px) consume
2520 tokens and are equivalent to $0.151 per image.

\*\* A customer-submitted request to Gemini may result in one or more
queries to Google Search. You will be charged for each individual search query
performed. Retrieved context (text or images) provided by Grounding with Google
Search is not charged as input tokens.

\\*\\*\\* Can be tested in Google AI Studio.

## Gemini 3.1 Flash Lite Image (Nano Banana 2 Lite) 🍌

_[`gemini-3.1-flash-lite-image`](https://ai.google.dev/gemini-api/docs/models/gemini-3.1-flash-lite-image)_

[Try it in Google AI Studio](https://aistudio.google.com/prompts/new_chat?model=gemini-3.1-flash-lite-image)

Designed as the efficiency specialist of the image generation family, the Gemini 3.1
Flash Lite Image model is designed for ultra-low latency and cost-effective image
generation and editing.

[Standard](https://ai.google.dev/gemini-api/docs/pricing#standard)[Batch](https://ai.google.dev/gemini-api/docs/pricing#batch)More

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $0.25 (text/image/video) |
| Output price | Not available | $1.50 (text and thinking)<br> $30.00 (images)<br> Equivalent to $0.0336 per 1K resolution image\* |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $0.125 (text/image/video) |
| Output price | Not available | $0.75 (text and thinking)<br> $15.00 (images)<br> Equivalent to $0.0168 per 1K resolution image\* |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

\* Image output is priced at $30 per 1,000,000 tokens. Output images at 1K (1024x1024px) consume 1120 tokens and are equivalent to $0.0336 per image.

## Gemini 3.8 Flash TTS

_[`gemini-3.8-flash-tts`](https://ai.google.dev/gemini-api/docs/models/gemini-3.8-flash-tts)_

[Try it in Google AI Studio](https://aistudio.google.com/prompts/new_chat?model=gemini-3.8-flash-tts)

Our 3.8 Flash Text-to-Speech audio model engineered for studio-grade voice fidelity, expressive acting, and long-form stability.

[Standard](https://ai.google.dev/gemini-api/docs/pricing#standard)[Batch](https://ai.google.dev/gemini-api/docs/pricing#batch)[Flex](https://ai.google.dev/gemini-api/docs/pricing#flex)[Priority](https://ai.google.dev/gemini-api/docs/pricing#priority)More

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Free of charge | $0.50 (text) through December 31, 2026.<br>$1.00 (text) starting January 1, 2027. |
| Output price | Free of charge | $9.00 (audio) through December 31, 2026.<br>$18.00 (audio) starting January 1, 2027.<br>Equivalent to $0.00225 per 10s audio\* through December 31, 2026.<br>Equivalent to $0.0045 per 10s audio\* starting January 1, 2027. |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $0.25 (text) through December 31, 2026.<br>$0.50 (text) starting January 1, 2027. |
| Output price | Not available | $4.50 (audio) through December 31, 2026.<br>$9.00 (audio) starting January 1, 2027.<br>Equivalent to $0.001125 per 10s audio\* through December 31, 2026.<br>Equivalent to $0.00225 per 10s audio\* starting January 1, 2027. |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $0.25 (text) through December 31, 2026.<br>$0.50 (text) starting January 1, 2027. |
| Output price | Not available | $4.50 (audio) through December 31, 2026.<br>$9.00 (audio) starting January 1, 2027.<br>Equivalent to $0.001125 per 10s audio\* through December 31, 2026.<br>Equivalent to $0.00225 per 10s audio\* starting January 1, 2027. |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Free of charge | $0.90 (text) through December 31, 2026.<br>$1.80 (text) starting January 1, 2027. |
| Output price | Free of charge | $16.20 (audio) through December 31, 2026.<br>$32.40 (audio) starting January 1, 2027.<br>Equivalent to $0.00405 per 10s audio\* through December 31, 2026.<br>Equivalent to $0.0081 per 10s audio\* starting January 1, 2027. |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

\* Audio tokens correspond to 25 tokens per second of audio.

## Gemini 3.8 Flash-Lite TTS

_[`gemini-3.8-flash-lite-tts`](https://ai.google.dev/gemini-api/docs/models/gemini-3.8-flash-lite-tts)_

[Try it in Google AI Studio](https://aistudio.google.com/prompts/new_chat?model=gemini-3.8-flash-lite-tts)

Our 3.8 Flash-Lite Text-to-Speech audio model optimized for high-throughput, low-latency, and cost-efficient conversational speech.

[Standard](https://ai.google.dev/gemini-api/docs/pricing#standard)[Batch](https://ai.google.dev/gemini-api/docs/pricing#batch)[Flex](https://ai.google.dev/gemini-api/docs/pricing#flex)[Priority](https://ai.google.dev/gemini-api/docs/pricing#priority)More

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Free of charge | $0.50 (text) through December 31, 2026.<br>$1.00 (text) starting January 1, 2027. |
| Output price | Free of charge | $6.00 (audio) through December 31, 2026.<br>$12.00 (audio) starting January 1, 2027.<br>Equivalent to $0.0015 per 10s audio\* through December 31, 2026.<br>Equivalent to $0.003 per 10s audio\* starting January 1, 2027. |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $0.25 (text) through December 31, 2026.<br>$0.50 (text) starting January 1, 2027. |
| Output price | Not available | $3.00 (audio) through December 31, 2026.<br>$6.00 (audio) starting January 1, 2027.<br>Equivalent to $0.00075 per 10s audio\* through December 31, 2026.<br>Equivalent to $0.0015 per 10s audio\* starting January 1, 2027. |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $0.25 (text) through December 31, 2026.<br>$0.50 (text) starting January 1, 2027. |
| Output price | Not available | $3.00 (audio) through December 31, 2026.<br>$6.00 (audio) starting January 1, 2027.<br>Equivalent to $0.00075 per 10s audio\* through December 31, 2026.<br>Equivalent to $0.0015 per 10s audio\* starting January 1, 2027. |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Free of charge | $0.90 (text) through December 31, 2026.<br>$1.80 (text) starting January 1, 2027. |
| Output price | Free of charge | $10.80 (audio) through December 31, 2026.<br>$21.60 (audio) starting January 1, 2027.<br>Equivalent to $0.0027 per 10s audio\* through December 31, 2026.<br>Equivalent to $0.0054 per 10s audio\* starting January 1, 2027. |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

\* Audio tokens correspond to 25 tokens per second of audio.

## Gemini 3.1 Flash TTS Preview

_[`gemini-3.1-flash-tts-preview`](https://ai.google.dev/gemini-api/docs/models/gemini-3.1-flash-tts-preview)_

[Try it in Google AI Studio](https://aistudio.google.com/prompts/new_chat?model=gemini-3.1-flash-tts-preview)

Our 3.1 Flash Text-to-Speech audio model optimized for price-performant,
low-latency, controllable speech generation.

[Standard](https://ai.google.dev/gemini-api/docs/pricing#standard)[Batch](https://ai.google.dev/gemini-api/docs/pricing#batch)More

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Free of charge | $1.00 (text) |
| Output price | Free of charge | $20.00 (audio) |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $0.50 (text) |
| Output price | Not available | $10.00 (audio) |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

\* Audio tokens correspond to 25 tokens per second of audio.

## Gemini 3 Flash Preview

_[`gemini-3-flash-preview`](https://ai.google.dev/gemini-api/docs/models/gemini-3-flash-preview)_

[Try it in Google AI Studio](https://aistudio.google.com/?model=gemini-3-flash-preview)

Our legacy Flash model, providing baseline speed and intelligence.

[Standard](https://ai.google.dev/gemini-api/docs/pricing#standard)[Batch](https://ai.google.dev/gemini-api/docs/pricing#batch)[Flex](https://ai.google.dev/gemini-api/docs/pricing#flex)[Priority](https://ai.google.dev/gemini-api/docs/pricing#priority)More

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Free of charge | $0.50 (text / image / video)<br>$1.00 (audio) |
| Output price (including thinking tokens) | Free of charge | $3.00 |
| Context caching price | Free of charge | $0.05 (text / image / video)<br>$0.10 (audio)<br>$1.00 / 1,000,000 tokens per hour (storage price) |
| Grounding with Google Search\* | Not available\*\* | 5,000 free search requests per month (shared across all Gemini 3 and newer models), then $14 per 1,000 requests. |
| Grounding with Google Maps | Not available\*\* | 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000 search queries. |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $0.25 (text / image / video)<br>$0.50 (audio) |
| Output price (including thinking tokens) | Not available | $1.50 |
| Context caching price | Not available | _Same as Standard_<br> $0.05 (text / image / video)<br> $0.10 (audio)<br> $1.00 / 1,000,000 tokens per hour (storage price) |
| Grounding with Google Search\* | Not available\*\* | 5,000 free search requests per month (shared across all Gemini 3 and newer models), then $14 per 1,000 requests. |
| Grounding with Google Maps | Not available\*\* | 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000 search queries. |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $0.25 (text / image / video)<br>$0.50 (audio) |
| Output price (including thinking tokens) | Not available | $1.50 |
| Context caching price | Not available | _Same as Standard_<br> $0.05 (text / image / video)<br> $0.10 (audio)<br> $1.00 / 1,000,000 tokens per hour (storage price) |
| Grounding with Google Search\* | Not available\*\* | 5,000 free search requests per month (shared across all Gemini 3 and newer models), then $14 per 1,000 requests. |
| Grounding with Google Maps | Not available\*\* | 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000 search queries. |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Free of charge | $0.90 (text / image / video)<br>$1.80 (audio) |
| Output price (including thinking tokens) | Free of charge | $5.40 |
| Context caching price | Free of charge | $0.09 (text / image / video)<br>$0.18 (audio)<br>$1.80 / 1,000,000 tokens per hour (storage price) |
| Grounding with Google Search\* | Not available\*\* | 5,000 free search requests per month (shared across all Gemini 3 and newer models), then $14 per 1,000 requests. |
| Grounding with Google Maps | Not available\*\* | 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000 search queries. |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

\* A customer-submitted request to Gemini may result in one or more
queries to Google Search. You will be charged for each individual search query
performed.

\*\* Can be tested in Google AI Studio.

## Gemini 3 Pro Image (Nano Banana Pro) 🍌

_[`gemini-3-pro-image`](https://ai.google.dev/gemini-api/docs/models/gemini-3-pro-image)_

[Try it in Google AI Studio](https://aistudio.google.com/prompts/new_chat?model=gemini-3-pro-image)

Our native image generation model, optimized for speed, flexibility, and
contextual understanding. **Text input and output** is priced the same as
[Gemini 3.1 Pro](https://ai.google.dev/gemini-api/docs/pricing#gemini-3.1-pro-preview).

[Standard](https://ai.google.dev/gemini-api/docs/pricing#standard)[Batch](https://ai.google.dev/gemini-api/docs/pricing#batch)[Flex](https://ai.google.dev/gemini-api/docs/pricing#flex)[Priority](https://ai.google.dev/gemini-api/docs/pricing#priority)More

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $2.00 (text/image),<br> equivalent to $0.0011 per image\* |
| Output price | Not available | $12.00 (text and thinking)<br> $120.00 (images)<br> Equivalent to $0.134 per 1K/2K image\*\*<br> and $0.24 per 4K image\*\* |
| Grounding with Google Search\\*\\*\\* | Not available\\*\\*\\*\* | 5,000 free search requests per month (shared across all Gemini 3 and newer models), then $14 per 1,000 requests. |
| Used to improve our products | Not available | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $1.00 (text),<br>$0.0006 (image)\* |
| Output price | Not available | $6.00 (text and thinking)<br> $0.067 per 1K/2K image\*\*<br> $0.12 per 4K image\*\* |
| Used to improve our products | Not available | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $1.00 (text),<br>$0.0006 (image)\* |
| Output price | Not available | $6.00 (text and thinking)<br> $0.067 per 1K/2K image\*\*<br> $0.12 per 4K image\*\* |
| Used to improve our products | Not available | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $3.60 (text/image) |
| Output price | Not available | $21.60 (text and thinking)<br> $216.00 (images) |
| Grounding with Google Search\\*\\*\\* | Not available\\*\\*\\*\* | 5,000 free search requests per month (shared across all Gemini 3 and newer models), then $14 per 1,000 requests. |
| Used to improve our products | Not available | [No](https://ai.google.dev/gemini-api/terms) |

\* Image input is set at 560 tokens or $0.0011 per image.

\*\* Image output is priced at $120 per 1,000,000 tokens. Output
images from 1024x1024px (1K) and up to 2048x2048px (2K) consume 1120 tokens and
are equivalent to $0.134 per image. Output images up to 4096x4096px (4K) consume
2000 tokens and are equivalent to $0.24 per image.

\\*\\*\\* A customer-submitted request to Gemini may result in one or more
queries to Google Search. You will be charged for each individual search query
performed.

\\*\\*\\*\* Can be tested in Google AI Studio.

## Gemini 2.5 Pro

_[`gemini-2.5-pro`](https://ai.google.dev/gemini-api/docs/models/gemini-2.5-pro)_

[Try it in Google AI Studio](https://aistudio.google.com/?model=gemini-2.5-pro)

A Pro model which excels at coding and complex reasoning tasks.

[Standard](https://ai.google.dev/gemini-api/docs/pricing#standard)[Batch](https://ai.google.dev/gemini-api/docs/pricing#batch)[Flex](https://ai.google.dev/gemini-api/docs/pricing#flex)[Priority](https://ai.google.dev/gemini-api/docs/pricing#priority)More

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Free of charge | $1.25, prompts <= 200k tokens<br>$2.50, prompts > 200k tokens |
| Output price (including thinking tokens) | Free of charge | $10.00, prompts <= 200k tokens<br>$15.00, prompts > 200k |
| Context caching price | Not available | $0.125, prompts <= 200k tokens<br>$0.25, prompts > 200k<br>$4.50 / 1,000,000 tokens per hour (storage price) |
| Grounding with Google Search | Not available | 1,500 RPD (free), then $35 / 1,000 grounded prompts |
| Grounding with Google Maps | Not available | 10,000 RPD (free), then $25 / 1,000 grounded prompts |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $0.625, prompts <= 200k tokens<br>$1.25, prompts > 200k tokens |
| Output price (including thinking tokens) | Not available | $5.00, prompts <= 200k tokens<br>$7.50, prompts > 200k |
| Context caching price | Not available | $0.125, prompts <= 200k tokens<br>$0.25, prompts > 200k<br>$4.50 / 1,000,000 tokens per hour (storage price) |
| Grounding with Google Search | Not available | 1,500 RPD (free), then $35 / 1,000 grounded prompts |
| Grounding with Google Maps | Not available | Not available |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $0.625, prompts <= 200k tokens<br>$1.25, prompts > 200k tokens |
| Output price (including thinking tokens) | Not available | $5.00, prompts <= 200k tokens<br>$7.50, prompts > 200k |
| Context caching price | Not available | $0.125, prompts <= 200k tokens<br>$0.25, prompts > 200k<br>$4.50 / 1,000,000 tokens per hour (storage price) |
| Grounding with Google Search | Not available | 1,500 RPD (free), then $35 / 1,000 grounded prompts |
| Grounding with Google Maps | Not available | Not available |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Free of charge | $2.25, prompts <= 200k tokens<br>$4.50, prompts > 200k tokens |
| Output price (including thinking tokens) | Free of charge | $18.00, prompts <= 200k tokens<br>$27.00, prompts > 200k |
| Context caching price | Not available | $0.225, prompts <= 200k tokens<br>$0.45, prompts > 200k<br>$8.10 / 1,000,000 tokens per hour (storage price) |
| Grounding with Google Search | Not available | 1,500 RPD (free), then $35 / 1,000 grounded prompts |
| Grounding with Google Maps | Not available | 10,000 RPD (free), then $25 / 1,000 grounded prompts |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

## Gemini 2.5 Flash

_[`gemini-2.5-flash`](https://ai.google.dev/gemini-api/docs/models/gemini-2.5-flash)_

[Try it in Google AI Studio](https://aistudio.google.com/?model=gemini-2.5-flash)

Our first hybrid reasoning model which supports a 1M token context window and
has thinking budgets.

[Standard](https://ai.google.dev/gemini-api/docs/pricing#standard)[Batch](https://ai.google.dev/gemini-api/docs/pricing#batch)[Flex](https://ai.google.dev/gemini-api/docs/pricing#flex)[Priority](https://ai.google.dev/gemini-api/docs/pricing#priority)More

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Free of charge | $0.30 (text / image / video)<br>$1.00 (audio) |
| Output price (including thinking tokens) | Free of charge | $2.50 |
| Context caching price | Not available | $0.03 (text / image / video)<br>$0.1 (audio)<br>$1.00 / 1,000,000 tokens per hour (storage price) |
| Grounding with Google Search | Free of charge, up to 500 RPD (limit shared with Flash-Lite RPD) | 1,500 RPD (free, limit shared with Flash-Lite RPD), then $35 / 1,000 grounded prompts |
| Grounding with Google Maps | 500 RPD | 1,500 RPD (free), then $25 / 1,000 grounded prompts |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $0.15 (text / image / video)<br>$0.50 (audio) |
| Output price (including thinking tokens) | Not available | $1.25 |
| Context caching price | Not available | $0.03 (text / image / video)<br>$0.1 (audio)<br>$1.00 / 1,000,000 tokens per hour (storage price) |
| Grounding with Google Search | Not available | 1,500 RPD (free, limit shared with Flash-Lite RPD), then $35 / 1,000 grounded prompts |
| Grounding with Google Maps | Not available | Not available |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $0.15 (text / image / video)<br>$0.50 (audio) |
| Output price (including thinking tokens) | Not available | $1.25 |
| Context caching price | Not available | $0.03 (text / image / video)<br>$0.1 (audio)<br>$1.00 / 1,000,000 tokens per hour (storage price) |
| Grounding with Google Search | Not available | 1,500 RPD (free, limit shared with Flash-Lite RPD), then $35 / 1,000 grounded prompts |
| Grounding with Google Maps | Not available | Not available |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Free of charge | $0.54 (text / image / video)<br>$1.80 (audio) |
| Output price (including thinking tokens) | Free of charge | $4.50 |
| Context caching price | Not available | $0.054 (text / image / video)<br>$0.18 (audio)<br>$1.80 / 1,000,000 tokens per hour (storage price) |
| Grounding with Google Search | Free of charge, up to 500 RPD (limit shared with Flash-Lite RPD) | 1,500 RPD (free, limit shared with Flash-Lite RPD), then $35 / 1,000 grounded prompts |
| Grounding with Google Maps | 500 RPD | 1,500 RPD (free), then $25 / 1,000 grounded prompts |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

## Gemini 2.5 Flash-Lite

_[`gemini-2.5-flash-lite`](https://ai.google.dev/gemini-api/docs/models/gemini-2.5-flash-lite)_

[Try it in Google AI Studio](https://aistudio.google.com/?model=gemini-2.5-flash-lite)

A small and cost effective model, built for at scale usage.

[Standard](https://ai.google.dev/gemini-api/docs/pricing#standard)[Batch](https://ai.google.dev/gemini-api/docs/pricing#batch)[Flex](https://ai.google.dev/gemini-api/docs/pricing#flex)[Priority](https://ai.google.dev/gemini-api/docs/pricing#priority)More

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price (text, image, video) | Free of charge | $0.10 (text / image / video)<br>$0.30 (audio) |
| Output price (including thinking tokens) | Free of charge | $0.40 |
| Context caching price | Not available | $0.01 (text / image / video)<br>$0.03 (audio)<br>$1.00 / 1,000,000 tokens per hour (storage price) |
| Grounding with Google Search | Free of charge, up to 500 RPD (limit shared with Flash RPD) | 1,500 RPD (free, limit shared with Flash RPD), then $35 / 1,000 grounded prompts |
| Grounding with Google Maps | 500 RPD | 1,500 RPD (free), then $25 / 1,000 grounded prompts |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price (text, image, video) | Not available | $0.05 (text / image / video)<br>$0.15 (audio) |
| Output price (including thinking tokens) | Not available | $0.20 |
| Context caching price | Not available | $0.01 (text / image / video)<br>$0.03 (audio)<br>$1.00 / 1,000,000 tokens per hour (storage price) |
| Grounding with Google Search | Not available | 1,500 RPD (free, limit shared with Flash RPD), then $35 / 1,000 grounded prompts |
| Grounding with Google Maps | Not available | Not available |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price (text, image, video) | Not available | $0.05 (text / image / video)<br>$0.15 (audio) |
| Output price (including thinking tokens) | Not available | $0.20 |
| Context caching price | Not available | $0.01 (text / image / video)<br>$0.03 (audio)<br>$1.00 / 1,000,000 tokens per hour (storage price) |
| Grounding with Google Search | Not available | 1,500 RPD (free, limit shared with Flash RPD), then $35 / 1,000 grounded prompts |
| Grounding with Google Maps | Not available | Not available |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price (text, image, video) | Free of charge | $0.18 (text / image / video)<br>$0.54 (audio) |
| Output price (including thinking tokens) | Free of charge | $0.72 |
| Context caching price | Not available | $0.018 (text / image / video)<br>$0.054 (audio)<br>$1.80 / 1,000,000 tokens per hour (storage price) |
| Grounding with Google Search | Free of charge, up to 500 RPD (limit shared with Flash RPD) | 1,500 RPD (free, limit shared with Flash RPD), then $35 / 1,000 grounded prompts |
| Grounding with Google Maps | 500 RPD | 1,500 RPD (free), then $25 / 1,000 grounded prompts |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

## Gemini 2.5 Flash Native Audio (Live API)

_[`gemini-2.5-flash-native-audio-preview-12-2025`](https://ai.google.dev/gemini-api/docs/models/gemini-2.5-flash-native-audio-preview-12-2025)_

[Try it in Google AI Studio](https://aistudio.google.com/app/live#gemini-2.5-flash-native-audio-preview-12-2025)

Our [Live API](https://ai.google.dev/gemini-api/docs/live) native audio models optimized for higher
quality audio outputs with better pacing, voice naturalness, verbosity, and
mood.

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Free of charge | $0.50 (text)<br>$3.00 (audio / video) |
| Output price (including thinking tokens) | Free of charge | $2.00 (text)<br>$12.00 (audio) |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

## Gemini 2.5 Flash Image (Nano Banana) 🍌

_[`gemini-2.5-flash-image`](https://ai.google.dev/gemini-api/docs/models/gemini-2.5-flash-image)_

[Try it in Google AI Studio](https://aistudio.google.com/?model=gemini-2.5-flash-image)

A native image generation model, optimized for speed, flexibility, and
contextual understanding. Text input and output is priced the same as
[2.5 Flash](https://ai.google.dev/gemini-api/docs/pricing#gemini-2.5-flash).

[Standard](https://ai.google.dev/gemini-api/docs/pricing#standard)[Batch](https://ai.google.dev/gemini-api/docs/pricing#batch)[Flex](https://ai.google.dev/gemini-api/docs/pricing#flex)[Priority](https://ai.google.dev/gemini-api/docs/pricing#priority)More

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $0.30 (text / image) |
| Output price | Not available | $0.039 per image\* |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $0.15 (text / image) |
| Output price | Not available | $0.0195 per image\* |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $0.15 (text / image) |
| Output price | Not available | $0.0195 per image\* |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $0.54 (text / image) |
| Output price | Not available | $0.0702 per image\* |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

\[\*\] Image output is priced at $30 per 1,000,000 tokens. Output images up to
1024x1024px consume 1290 tokens and are equivalent to $0.039 per image.

## Gemini 2.5 Flash Preview TTS

_[`gemini-2.5-flash-preview-tts`](https://ai.google.dev/gemini-api/docs/models/gemini-2.5-flash-preview-tts)_

[Try it in Google AI Studio](https://aistudio.google.com/generate-speech)

Our 2.5 Flash text-to-speech audio model optimized for price-performant,
low-latency, controllable speech generation.

[Standard](https://ai.google.dev/gemini-api/docs/pricing#standard)[Batch](https://ai.google.dev/gemini-api/docs/pricing#batch)More

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Free of charge | $0.50 (text) |
| Output price | Free of charge | $10.00 (audio) |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $0.25 (text) |
| Output price | Not available | $5.00 (audio) |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

## Gemini 2.5 Pro Preview TTS

_[`gemini-2.5-pro-preview-tts`](https://ai.google.dev/gemini-api/docs/models/gemini-2.5-pro-preview-tts)_

[Try it in Google AI Studio](https://aistudio.google.com/generate-speech)

Our 2.5 Pro text-to-speech audio model optimized for powerful, low-latency
speech generation for more natural outputs and easier to steer prompts.

[Standard](https://ai.google.dev/gemini-api/docs/pricing#standard)[Batch](https://ai.google.dev/gemini-api/docs/pricing#batch)More

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $1.00 (text) |
| Output price | Not available | $20.00 (audio) |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $0.50 (text) |
| Output price | Not available | $10.00 (audio) |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

## Lyria 3.5

_[`lyria-3.5`](https://ai.google.dev/gemini-api/docs/models/lyria-3.5)_

Google's music generation model.

|  | Free Tier | Paid Tier, per request in USD |
| --- | --- | --- |
| Lyria 3.5 (Full Song) | Not available | $0.08 per song |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

## Lyria 3

_[`lyria-3-clip-preview`](https://ai.google.dev/gemini-api/docs/models/lyria-3-clip-preview) and [`lyria-3-pro-preview`](https://ai.google.dev/gemini-api/docs/models/lyria-3-pro-preview)_

Google's family of legacy music generation models.

|  | Free Tier | Paid Tier, per request in USD |
| --- | --- | --- |
| Lyria 3 Clip Preview (30s) | Not available | $0.04 per song |
| Lyria 3 Pro Preview (Full Song) | Not available | $0.08 per song |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

## Gemini Embedding 2

_[`gemini-embedding-2`](https://ai.google.dev/gemini-api/docs/models/gemini-embedding-2)_

[Try the API](https://ai.google.dev/gemini-api/docs/embeddings)

Our first multimodal embedding model, mapping text, images, video, audio, and
PDFs into a unified embedding space.

[Standard](https://ai.google.dev/gemini-api/docs/pricing#standard)[Batch](https://ai.google.dev/gemini-api/docs/pricing#batch)More

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Text input price | Free of charge | $0.20 |
| Image input price | Free of charge | $0.45 ($0.00012 per image) |
| Audio input price | Free of charge | $6.50 ($0.00016 per second) |
| Video input price | Free of charge | $12.00 ($0.00079 per frame) |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Text input price | Not available | $0.10 |
| Image input price | Not available | $0.225 ($0.00006 per image) |
| Audio input price | Not available | $3.25 ($0.00008 per second) |
| Video input price | Not available | $6.00 ($0.000395 per frame) |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

## Gemini Robotics ER 2 Preview

_[`gemini-robotics-er-2-preview`](https://ai.google.dev/gemini-api/docs/models/gemini-robotics-er-2-preview)_

[Try it in Google AI Studio](https://aistudio.google.com/?model=gemini-robotics-er-2-preview)

Gemini Robotics ER 2, short for Gemini Robotics Embodied Reasoning 2, is a
vision-language model endpoint that enables robots to understand their environments
precisely, supporting agentic orchestration of robots, video progress
understanding, multi-robot collaboration, and advanced spatial reasoning.

[Standard](https://ai.google.dev/gemini-api/docs/pricing#standard)[Batch](https://ai.google.dev/gemini-api/docs/pricing#batch)More

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Free of charge | $1.00 (text / image / video / audio) through December 31, 2026.<br>$2.00 (text / image / video / audio) starting January 1, 2027. |
| Output price (including thinking tokens) | Free of charge | $5.00 through December 31, 2026.<br>$10.00 starting January 1, 2027. |
| Context caching price | Not available | $0.10 through December 31, 2026.<br>$0.20 starting January 1, 2027.<br>$0.50 / 1,000,000 tokens per hour (storage price) through December 31, 2026.<br>$1.00 / 1,000,000 tokens per hour (storage price) starting January 1, 2027. |
| Grounding with Google Search | Not available | 5,000 free search requests per month (shared across all Gemini 3 and newer models), then $14 per 1,000 requests. |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Not available | $0.50 (text / image / video / audio) through December 31, 2026.<br>$1.00 (text / image / video / audio) starting January 1, 2027. |
| Output price (including thinking tokens) | Not available | $2.50 through December 31, 2026.<br>$5.00 starting January 1, 2027. |
| Context caching price | Not available | $0.05 through December 31, 2026.<br>$0.10 starting January 1, 2027.<br>$0.50 / 1,000,000 tokens per hour (storage price) through December 31, 2026.<br>$1.00 / 1,000,000 tokens per hour (storage price) starting January 1, 2027. |
| Grounding with Google Search | Not available | 5,000 free search requests per month (shared across all Gemini 3 and newer models), then $14 per 1,000 requests. |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

## Gemini Robotics ER 2 Streaming Preview

_[`gemini-robotics-er-2-streaming-preview`](https://ai.google.dev/gemini-api/docs/models/gemini-robotics-er-2-streaming-preview)_

[Try it in Google AI Studio](https://aistudio.google.com/?model=gemini-robotics-er-2-streaming-preview)

Gemini Robotics ER 2 Streaming is a vision-language model endpoint for robotics
optimized for real-time text streaming using the Live API. It accepts text,
image, video, and audio input and supports bidirectional streaming with
function calling.

[Standard](https://ai.google.dev/gemini-api/docs/pricing#standard)More

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Free of charge | $1.00 (text / image / video / audio) through December 31, 2026.<br>$2.00 (text / image / video / audio) starting January 1, 2027. |
| Output price | Free of charge | $5.00 through December 31, 2026.<br>$10.00 starting January 1, 2027. |
| Grounding with Google Search | Not available | 5,000 free search requests per month (shared across all Gemini 3 and newer models), then $14 per 1,000 requests. |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

## [Gemma 4](https://ai.google.dev/gemma/docs/core/model_card_4)

Our lightweight, state-of the art, open model built from the same technology
that powers our Gemini models.

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| Input price | Free of charge | Not available |
| Output price | Free of charge | Not available |
| Context caching price | Free of charge | Not available |
| Context caching (storage) | Free of charge | Not available |
| Tuning price | Not available | Not available |
| Grounding with Google Search | Not available | Not available |
| Used to improve our products | [Yes](https://ai.google.dev/gemini-api/terms) | [No](https://ai.google.dev/gemini-api/terms) |

## Pricing for tools

Tools are priced at their own rates, applied to the model using them.
Check the [Models](https://ai.google.dev/gemini-api/docs/models) page for which tools are available
to each model.

|  | Free Tier | Paid Tier, per 1M tokens in USD |
| --- | --- | --- |
| [Google Search](https://ai.google.dev/gemini-api/docs/google-search#pricing) | 500 RPD free (limit shared for Flash and Flash-Lite).<br>Not available for Pro. | Gemini 2.5 models:<br> 1,500 RPD free (limit shared for Flash and Flash-Lite).<br>Then $35 / 1,000 grounded prompts<br> Gemini 3 and newer models:<br> 5,000 free search requests per month (shared across all Gemini 3 and newer models), then $14 per 1,000 requests. |
| [Google Maps](https://ai.google.dev/gemini-api/docs/maps-grounding#pricing-and-rate-limits) | 500 RPD<br>Not available for Pro. | Gemini 2.5 models:<br> 1,500 RPD free (limit shared for Flash and Flash-Lite)<br>10,000 RPD free for Pro.<br>Then $25 / 1,000 grounded prompts<br> Gemini 3 and newer models:<br> 5,000 requests per month (free, shared across all Gemini 3 and newer models), then $14 / 1,000 search queries. |
| [Code execution](https://ai.google.dev/gemini-api/docs/code-execution#billing) | Free of charge | Code execution is billed at the standard token rates for the selected model.<br> Costs are determined solely by the tool's usage, no charges are accrued<br> for the session runtime. The generated code and execution results are billed as<br> **Output tokens** when created, and as<br> **Input tokens** when the model uses them as part of its<br> iterative reasoning process. |
| [URL context](https://ai.google.dev/gemini-api/docs/url-context#limitations) | Free of charge | Charged as input tokens per model pricing. |
| [Computer use](https://ai.google.dev/gemini-api/docs/computer-use) | Not available | Charged as regular tokens per model pricing (e.g., standard [Gemini 3.8 Flash](https://ai.google.dev/gemini-api/docs/pricing#gemini-3.8-flash) pricing). |
| [File search](https://ai.google.dev/gemini-api/docs/file-search#pricing) | Free of charge | Charged for [embeddings](https://ai.google.dev/gemini-api/docs/pricing#gemini-embedding-2) at $0.15 / 1M tokens.<br>Retrieved document tokens charged as regular tokens per model pricing. |
| [Custom Tools endpoint (Gemini 3.1 Pro Preview)](https://ai.google.dev/gemini-api/docs/models/gemini-3.1-pro-preview) | Not available | Same as [Gemini 3.1 Pro Preview](https://ai.google.dev/gemini-api/docs/pricing#gemini-3.1-pro-preview) pricing |

## Pricing for agents

Agent usage costs are calculated based on the underlying token
consumption and usage of the tools.

|  | Model | Tools |
| --- | --- | --- |
| [Gemini Deep Research agent](https://ai.google.dev/gemini-api/docs/deep-research) | All model inference is charged at standard Gemini list rates,<br> including input, output, and intermediate input / reasoning tokens generated<br> during agentic loops. | Tool usage fees apply per existing pricing<br> structure, maintaining standard distinctions for Search Grounding (retrieved<br> tokens excluded) versus Url\_context / File Search (retrieved tokens included in<br> all other tools). |
| [Managed agents in Gemini API](https://ai.google.dev/gemini-api/docs/agents) | All model inference is charged at standard Gemini list rates,<br> including input, output, and intermediate input / reasoning tokens generated<br> during agentic loops. (See [pricing details](https://ai.google.dev/gemini-api/docs/agents#pricing)). | Environment compute (CPU, memory, sandbox execution) is not billed during the preview period. |
| [Antigravity Agent](https://ai.google.dev/gemini-api/docs/antigravity-agent) | All model inference is charged at standard Gemini list rates,<br> including input, output, and intermediate input / reasoning tokens generated<br> during agentic loops. (See [pricing details](https://ai.google.dev/gemini-api/docs/agents#pricing)). | Environment compute (CPU, memory, sandbox execution) is not billed during the preview period. |

## Notes

- **Agentic video understanding:** When using agentic video understanding,
token usage is variable based on the content loaded by the model rather than
full video length. This typically results in up to 88% fewer input tokens for
long-form video, though token counts depend on query complexity and dynamic
sampling depth (which may exceed 1 FPS for detailed visual segments). See
[Agentic video understanding](https://ai.google.dev/gemini-api/docs/video-understanding#agentic-video-understanding).
- **Document token billing:** Tokens for the `DOCUMENT` modality (for example, PDFs) are billed at the image token rate. In API responses, these tokens appear under the `DOCUMENT` modality within `promptTokensDetails`.
- Google AI Studio usage is free of charge in all [available regions](https://ai.google.dev/gemini-api/docs/available-regions). See [Billing FAQs](https://ai.google.dev/gemini-api/docs/billing) for details.
- Prices may differ from the prices listed here and the prices offered on
Gemini Enterprise Agent Platform. For Gemini Enterprise Agent Platform prices, see the [Gemini Enterprise Agent Platform pricing page](https://cloud.google.com/products/gemini-enterprise-agent-platform).
- If you are using [dynamic retrieval](https://ai.google.dev/gemini-api/docs/grounding) to
optimize costs, only requests that contain at least one grounding support URL
from the web in their response are charged for Grounding with Google Search.
Costs for Gemini always apply. Rate limits are subject to change.

Except as otherwise noted, the content of this page is licensed under the [Creative Commons Attribution 4.0 License](https://creativecommons.org/licenses/by/4.0/), and code samples are licensed under the [Apache 2.0 License](https://www.apache.org/licenses/LICENSE-2.0). For details, see the [Google Developers Site Policies](https://developers.google.com/site-policies). Java is a registered trademark of Oracle and/or its affiliates.

Last updated 2026-10-22 UTC.




\[\[\["Easy to understand","easyToUnderstand","thumb-up"\],\["Solved my problem","solvedMyProblem","thumb-up"\],\["Other","otherUp","thumb-up"\]\],\[\["Missing the information I need","missingTheInformationINeed","thumb-down"\],\["Too complicated / too many steps","tooComplicatedTooManySteps","thumb-down"\],\["Out of date","outOfDate","thumb-down"\],\["Samples / code issue","samplesCodeIssue","thumb-down"\],\["Other","otherDown","thumb-down"\]\],\["Last updated 2026-10-22 UTC."\],\[\],\[\]\]